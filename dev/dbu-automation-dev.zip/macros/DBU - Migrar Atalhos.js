await globalThis.DBUAutomation.migrateLauncherMacros({ overwrite: true });
