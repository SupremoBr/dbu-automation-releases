// ============================================================
// DBU Automation v1.8.12 DEV — Battle Born message router
// ============================================================
// Não recria a regra. Apenas encaminha ao(s) player(s) OWNER uma cópia de uma
// mensagem nativa de Battle Born que tenha sido criada sem eles como destino.
// ============================================================

const MODULE_ID = "dbu-automation-dev";
const VERSION = "1.8.12 DEV";
let hookId = null;

function isPrimaryGM() {
  const active = (game.users?.contents || [...(game.users || [])])
    .filter(user => user?.active && user?.isGM)
    .sort((a, b) => String(a.id).localeCompare(String(b.id)));
  return active[0]?.id === game.user?.id;
}

function isBattleBornMessage(message) {
  if (!message) return false;
  if (message.getFlag?.(MODULE_ID, "battleBornForwarded")) return false;
  const text = `${message.content || ""}\n${message.flavor || ""}`
    .replace(/<[^>]+>/g, " ")
    .toLowerCase();
  return /battle\s*[-_ ]?born/.test(text);
}

function actorFromMessage(message) {
  const actorId = message?.speaker?.actor || message?.getFlag?.("world", "actorId") || null;
  if (actorId) {
    const actor = game.actors?.get?.(actorId) || null;
    if (actor) return actor;
  }
  const tokenId = message?.speaker?.token || null;
  if (tokenId) {
    const live = canvas?.tokens?.get?.(tokenId)?.actor || null;
    if (live) return live;
    const scene = message?.speaker?.scene ? game.scenes?.get?.(message.speaker.scene) : null;
    const tokenDoc = scene?.tokens?.get?.(tokenId) || null;
    if (tokenDoc?.actor) return tokenDoc.actor;
    if (tokenDoc?.actorId) return game.actors?.get?.(tokenDoc.actorId) || null;
  }
  return null;
}

function playerOwners(actor) {
  if (!actor) return [];
  return (game.users?.contents || [...(game.users || [])]).filter(user => {
    if (!user?.active || user?.isGM) return false;
    try {
      return user.character?.id === actor.id || !!actor.testUserPermission?.(user, "OWNER");
    } catch {
      return user.character?.id === actor.id;
    }
  });
}

async function forwardBattleBorn(message) {
  if (!isPrimaryGM() || !isBattleBornMessage(message)) return;
  const actor = actorFromMessage(message);
  if (!actor) return;
  const owners = playerOwners(actor);
  if (!owners.length) return;
  // Mensagem pública já é visível ao player; não duplicar.
  if (!(message.whisper || []).length) return;

  const existingWhisper = new Set((message.whisper || []).map(String));
  const missing = owners.filter(user => !existingWhisper.has(String(user.id)));
  if (!missing.length && (message.whisper || []).length) return;

  await ChatMessage.create({
    speaker: foundry.utils.deepClone(message.speaker || ChatMessage.getSpeaker({ actor })),
    content: message.content || `<div><b>Battle Born — ${actor.name}</b></div>`,
    flavor: message.flavor || undefined,
    whisper: missing.length ? missing.map(user => user.id) : owners.map(user => user.id),
    flags: {
      [MODULE_ID]: {
        battleBornForwarded: true,
        battleBornSourceMessageId: message.id
      }
    }
  });
}

export function initializeBattleBornRouter() {
  if (hookId) {
    try { Hooks.off("createChatMessage", hookId); } catch {}
  }
  hookId = Hooks.on("createChatMessage", message => {
    forwardBattleBorn(message).catch(error => console.warn("DBU Battle Born router:", error));
  });
  const state = { initialized: true, version: VERSION, hookId };
  globalThis.DBU_BATTLE_BORN_ROUTER = state;
  console.log(`DBU Automation ${VERSION} | Battle Born router pronto`);
  return state;
}

export const BattleBornRouter = { initialize: initializeBattleBornRouter };
