// DBU Automation — integração de novo Round com o Combat Tracker

export function initializeRoundHooks({ dbuIsPrimaryGM } = {}) {
async function dbuNewRound(combat) {
  if (!dbuIsPrimaryGM()) return;

  const processed = new Set();

  for (const combatant of combat.combatants) {
    const actor = combatant.actor;

    if (
      !actor
      || processed.has(actor.id)
    ) {
      continue;
    }

    processed.add(actor.id);

    try {
      const sheet = actor.sheet;

      if (
        typeof sheet?._onCombatNewRound === "function"
      ) {
        await sheet._onCombatNewRound({
          preventDefault() {},
          stopPropagation() {}
        });

        console.log(
          `DBU | Novo Round -> ${actor.name}`
        );
      } else {
        console.warn(
          `DBU | _onCombatNewRound não encontrada para ${actor.name}`
        );
      }
    } catch (error) {
      console.error(
        `DBU | Novo Round ${actor.name}:`,
        error
      );
    }
  }
}

// ============================================================
// HOOK DO COMBAT TRACKER
// ============================================================

const combatHookId = Hooks.on(
  "updateCombat",
  async (combat, changes) => {
    if (
      !Object.prototype
        .hasOwnProperty
        .call(changes, "round")
    ) {
      return;
    }

    const round = Number(
      combat.round || 0
    );

    if (round <= 0) return;

    const key = `${combat.id}:${round}`;

    if (
      globalThis.DBU_BOOTSTRAP.lastCombatRound === key
    ) {
      return;
    }

    globalThis.DBU_BOOTSTRAP.lastCombatRound = key;

    await dbuNewRound(combat);
  }
);

globalThis.DBU_BOOTSTRAP.combatHookId =
  combatHookId;

  return { dbuNewRound, combatHookId };
}
