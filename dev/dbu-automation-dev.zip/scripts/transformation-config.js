// DBU Automation — configuração visual padrão de Transformações
//
// As regras mecânicas (bônus de atributos, Aspects, Traits, Stress Test etc.)
// NÃO ficam aqui. Elas continuam vindo de system.transformations / DBU 0.9.2.
//
// Este arquivo é apenas um fallback visual. Configuração nas Notes do Actor
// tem prioridade sobre este mapa.
//
// Exemplo:
// export const TRANSFORMATION_CONFIG = {
//   "Super Saiyan 1": {
//     token: "assets/Tokens/Goku-SSJ.webp",
//     aura: "assets/Auras/aura-classica.webm",
//     color: "#FFD700",
//     auraScale: 2.8,
//     tokenScale: 1
//   }
// };

export const TRANSFORMATION_CONFIG = {};
