// DBU Automation v1.8.1 — Core de Inicialização
import { getDefenseVisualSettings, getCombatVisualSettings } from "./visual-config.js";
import { prepareTerrainShield, resolveTerrainShield } from "./maneuvers.js";
// Migrado do Inicializador v6.6.

export async function initializeDBUAutomation() {
// ============================================================
// DBU-MRR-OLD — INICIALIZADOR GLOBAL v6.10
// ============================================================
//
// v6.5
// ✔ Mantém Ki + Capacity
// ✔ Mantém Pay original do ataque interceptado
// ✔ Mantém 1 defesa por personagem por ataque
// ✔ Mantém lock local + lock salvo no Actor
// ✔ Mantém atualização da carta pelo GM via socket
// ✔ Mantém novo round automático
// ✔ Mantém GIFs de defesa lidos de system.notes do personagem
// ✔ NOVO: Duel Clash aparece como opção diretamente na carta de defesa
// ✔ NOVO: defensor escolhe o Initiating Attack e abre o Duel nativo do DBU
// ✔ NOVO: Accept Duel usa automaticamente o ataque original recebido
// ✔ NOVO: Duel Escape usa automaticamente o atacante original
// ✔ NOVO: Ki Wager do Duel também consome Capacity
// ✔ NOVO: corrige limpeza dos locks locais de defesa
// ✔ NOVO v6.6: United Attack integrado à carta personalizada do Ataque v11.5
// ✔ NOVO v6.6: +1/2 FO/MA + Ki Wager (1/4 Max Capacity; Teamwork x2)
// ✔ NOVO v6.6: United Attack paga Ki + Capacity e registra 1/Round no Round Tracker
// ✔ NOVO v6.6: intercepta o botão United Attack da carta nativa e usa a mesma automação
// ✔ NOVO v6.6: em ataque multi-target, co-target pode entrar no Duel como United Duel
// ✔ NOVO v6.6: Wound atualizado antes das defesas usa todos os United Attacks confirmados
// ✔ NOVO v6.7: Attack/Defense rolls ficam secretos até todos os alvos confirmarem a defesa
// ✔ NOVO v6.7: dano é aplicado somente na revelação conjunta
// ✔ NOVO v6.7: bloqueia o REVEAL nativo do ataque enquanto houver alvos aguardando
// ✔ NOVO v6.8: dano fica pendente após o reveal para permitir Intervene
// ✔ NOVO v6.8: Parry bem-sucedido pode oferecer Reflect via módulo v1.4
// ✔ NOVO v6.9: bloqueia Roll Attack nativo se Cost + Wager exceder Ki ou Capacity disponível
// ✔ NOVO v6.10: confirma defesa de players via socket + fallback por flags do Actor
// ✔ NOVO v6.10: mostra imediatamente qual defesa foi selecionada sem revelar o resultado
// ✔ NOVO v7.0: defesa pelo Painel 2.0 usa o mesmo resolveDefense da carta
// ✔ NOVO v7.0: fases visuais configuráveis do Duel Clash
//
// Na aba Notes do personagem, use por exemplo:
//
// DODGE_GIF: https://site.com/dodge.gif
// PARRY_GIF: https://site.com/parry.gif
// DIRECT_HIT_GIF: https://site.com/hit.gif
// POWER_FLARE_GIF: https://site.com/flare.gif
// CROSS_COUNTER_GIF: https://site.com/counter.gif
// GUARD_GIF: https://site.com/guard.gif
// DEFENSE_GIF: https://site.com/fallback.gif
//
// DEFENSE_GIF é opcional e serve como fallback.
// ============================================================

const DBU_INIT_VERSION = "7.0";
const DBU_DEFENSE_SELECTOR = "[data-dbu-defense-v5]";
const DBU_SOCKET = "module.dbu-automation";
const DBU_PENDING_TIMEOUT = 120000;

const DBU_DEFENSE_GIF_CONFIG = {
  enabled: true,
  maxHeight: 240,
  objectFit: "contain"
};

// ============================================================
// LIMPAR VERSÃO ANTERIOR
// ============================================================

const previousBootstrap = globalThis.DBU_BOOTSTRAP;

if (previousBootstrap?.defenseClickHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.defenseClickHandler,
      true
    );
  } catch {}
}

if (previousBootstrap?.nativePayHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.nativePayHandler,
      true
    );
  } catch {}
}

if (previousBootstrap?.nativeAttackCapacityHookId) {
  try {
    Hooks.off(
      "renderActorSheet",
      previousBootstrap.nativeAttackCapacityHookId
    );
  } catch {}
}

if (previousBootstrap?.combatHookId) {
  try {
    Hooks.off(
      "updateCombat",
      previousBootstrap.combatHookId
    );
  } catch {}
}

if (previousBootstrap?.socketHandler) {
  // Limpa tanto o canal atual quanto o canal legado usado pelo dbu-auto-start.
  for (const channel of [DBU_SOCKET, "module.dbu-auto-start"]) {
    try {
      game.socket.off(
        channel,
        previousBootstrap.socketHandler
      );
    } catch {}
  }
}

// v6.5 — listeners/hooks adicionais do Duel Clash
if (previousBootstrap?.duelInjectHookId) {
  try {
    Hooks.off(
      "renderChatMessage",
      previousBootstrap.duelInjectHookId
    );
  } catch {}
}

if (previousBootstrap?.duelAcceptHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.duelAcceptHandler,
      true
    );
  } catch {}
}

if (previousBootstrap?.duelEscapeHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.duelEscapeHandler,
      true
    );
  } catch {}
}

if (previousBootstrap?.duelRevealHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.duelRevealHandler,
      true
    );
  } catch {}
}

// v6.6 — United Attack / United Duel
if (previousBootstrap?.unitedAttackHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.unitedAttackHandler,
      true
    );
  } catch {}
}

if (previousBootstrap?.unitedDuelHandler) {
  try {
    document.removeEventListener(
      "click",
      previousBootstrap.unitedDuelHandler,
      true
    );
  } catch {}
}

if (previousBootstrap?.unitedAttackActorHookId) {
  try {
    Hooks.off(
      "updateActor",
      previousBootstrap.unitedAttackActorHookId
    );
  } catch {}
}

// v6.7 — bloqueio do Reveal nativo até todas as defesas serem registradas.
if (previousBootstrap?.secretRevealHandler) {
  try {
    document.removeEventListener("click", previousBootstrap.secretRevealHandler, true);
  } catch {}
}

if (previousBootstrap?.defenseActorSyncHookId) {
  try {
    Hooks.off("updateActor", previousBootstrap.defenseActorSyncHookId);
  } catch {}
}

if (previousBootstrap?.secretRevealHookId) {
  try {
    Hooks.off("renderChatMessage", previousBootstrap.secretRevealHookId);
  } catch {}
}

if (globalThis.DBU_ATTACK_SYSTEM?.hookId) {
  try {
    Hooks.off(
      "renderChatMessage",
      globalThis.DBU_ATTACK_SYSTEM.hookId
    );
  } catch {}
}

if (globalThis.DBU_ATTACK_DEFENSE?.hookId) {
  try {
    Hooks.off(
      "renderChatMessage",
      globalThis.DBU_ATTACK_DEFENSE.hookId
    );
  } catch {}
}

delete globalThis.DBU_ATTACK_SYSTEM;
delete globalThis.DBU_ATTACK_DEFENSE;

globalThis.DBU_BOOTSTRAP = {
  version: DBU_INIT_VERSION,
  defenseClickHandler: null,
  nativePayHandler: null,
  nativeAttackCapacityHookId: null,
  combatHookId: null,
  socketHandler: null,
  duelInjectHookId: null,
  duelAcceptHandler: null,
  duelEscapeHandler: null,
  duelRevealHandler: null,
  unitedAttackHandler: null,
  unitedDuelHandler: null,
  unitedAttackActorHookId: null,
  defenseActorSyncHookId: null,
  secretRevealHandler: null,
  secretRevealHookId: null,
  lastCombatRound: null
};

globalThis.DBU_DEFENSE_LOCKS = new Set();
globalThis.DBU_PAY_LOCKS = new Set();
globalThis.DBU_DUEL_WAGER_LOCKS = new Set();
globalThis.DBU_UNITED_ATTACK_LOCKS = new Set();
globalThis.DBU_COMBAT_REVEAL_LOCKS = new Set();

// ============================================================
// HELPERS
// ============================================================

function dbuEsc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function dbuSleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function dbuPrepareSheet(actor) {
  const sheet = actor?.sheet;

  if (!sheet) {
    throw new Error(
      `Ficha de ${actor?.name || "Actor"} não encontrada.`
    );
  }

  await sheet.getData();
  return sheet;
}

// ============================================================
// GIFS DE DEFESA — NOTES DO PERSONAGEM
// ============================================================

function dbuValidateHttpUrl(value) {
  if (!value) return "";

  let url = String(value).trim();

  // Markdown: [texto](https://...)
  const markdown = url.match(/\((https?:\/\/[^)\s]+)\)/i);
  if (markdown?.[1]) {
    url = markdown[1];
  } else {
    const direct = url.match(/https?:\/\/[^\s<>"')\]]+/i);
    if (direct?.[0]) {
      url = direct[0];
    }
  }

  url = url.replace(/[.,;]+$/, "");

  try {
    const parsed = new URL(url);

    if (
      parsed.protocol !== "http:" &&
      parsed.protocol !== "https:"
    ) {
      return "";
    }

    return parsed.href;
  } catch {
    return "";
  }
}

function dbuNormalizeNoteTag(value) {
  return String(value ?? "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_")
    .replace(/_+/g, "_");
}

function dbuGetCharacterNotes(actor) {
  // DBU-MRR-OLD: a caixa Notes da ficha salva em system.notes.
  return String(actor?.system?.notes ?? "");
}

function dbuExtractNoteUrl(notes, acceptedTags) {
  if (!notes) return "";

  // Caso algum módulo/editor converta o conteúdo para HTML.
  let text = String(notes);

  try {
    if (/<[a-z][\s\S]*>/i.test(text)) {
      const element = document.createElement("div");
      element.innerHTML = text;
      text = element.innerText || element.textContent || text;
    }
  } catch {}

  const normalizedTags = new Set(
    acceptedTags.map(dbuNormalizeNoteTag)
  );

  const lines = text.split(/\r?\n/);

  for (const line of lines) {
    const match = line.match(/^\s*([^:]+?)\s*:\s*(.+?)\s*$/);
    if (!match) continue;

    const key = dbuNormalizeNoteTag(match[1]);
    if (!normalizedTags.has(key)) continue;

    const url = dbuValidateHttpUrl(match[2]);
    if (url) return url;
  }

  return "";
}

function dbuGetDefenseGif(defender, defenseType) {
  if (!DBU_DEFENSE_GIF_CONFIG.enabled) {
    return "";
  }

  const visualSettings = getDefenseVisualSettings(defender, defenseType);
  if (visualSettings?.gifMode === "custom") {
    return String(visualSettings.gif || "").trim();
  }
  if (visualSettings?.gifMode === "none") {
    return "";
  }

  const notes = dbuGetCharacterNotes(defender);

  const tagsByDefense = {
    dodge: [
      "DODGE_GIF"
    ],

    parry: [
      "PARRY_GIF"
    ],

    directHit: [
      "DIRECT_HIT_GIF",
      "DIRECTHIT_GIF"
    ],

    powerFlare: [
      "POWER_FLARE_GIF",
      "POWERFLARE_GIF"
    ],

    crossCounter: [
      "CROSS_COUNTER_GIF",
      "CROSSCOUNTER_GIF"
    ],

    guard: [
      "GUARD_GIF"
    ],

    duelClash: [
      "DUEL_CLASH_GIF",
      "DUELCLASH_GIF"
    ]
  };

  const specific = dbuExtractNoteUrl(
    notes,
    tagsByDefense[defenseType] || []
  );

  if (specific) {
    return specific;
  }

  return dbuExtractNoteUrl(
    notes,
    ["DEFENSE_GIF"]
  );
}

function dbuExtractNoteValue(notes, acceptedTags) {
  if (!notes) return "";

  let text = String(notes);
  try {
    if (/<[a-z][\s\S]*>/i.test(text)) {
      const element = document.createElement("div");
      element.innerHTML = text;
      text = element.innerText || element.textContent || text;
    }
  } catch {}

  const normalizedTags = new Set(acceptedTags.map(dbuNormalizeNoteTag));
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/^\s*([^:]+?)\s*:\s*(.+?)\s*$/);
    if (!match) continue;
    const key = dbuNormalizeNoteTag(match[1]);
    if (!normalizedTags.has(key)) continue;
    return String(match[2] || "").trim();
  }
  return "";
}

function dbuGetDefenseVisualMacro(defender, defenseType) {
  const visualSettings = getDefenseVisualSettings(defender, defenseType);
  if (visualSettings?.visualMode === "custom") {
    return String(visualSettings.visualMacro || "").trim();
  }
  if (visualSettings?.visualMode === "none") return "";

  const tagsByDefense = {
    dodge: ["DODGE_VISUAL"],
    parry: ["PARRY_VISUAL"],
    directHit: ["DIRECT_HIT_VISUAL", "DIRECTHIT_VISUAL"],
    powerFlare: ["POWER_FLARE_VISUAL", "POWERFLARE_VISUAL"],
    crossCounter: ["CROSS_COUNTER_VISUAL", "CROSSCOUNTER_VISUAL"],
    guard: ["GUARD_VISUAL"],
    duelClash: ["DUEL_CLASH_VISUAL", "DUELCLASH_VISUAL"]
  };

  const notes = dbuGetCharacterNotes(defender);
  return dbuExtractNoteValue(notes, tagsByDefense[defenseType] || [])
    || dbuExtractNoteValue(notes, ["DEFENSE_VISUAL"]);
}

async function dbuRunDefenseVisual(defender, defenseType, result = {}) {
  const macroName = dbuGetDefenseVisualMacro(defender, defenseType);
  if (!macroName) return;

  const macro = game.macros.getName(macroName);
  if (!macro) {
    console.warn(`DBU | Macro visual de defesa não encontrada: ${macroName}`);
    return;
  }

  const tokens = defender.getActiveTokens?.() || [];
  const token = tokens[0] || null;

  try {
    await macro.execute({
      actor: defender,
      token,
      defender,
      defenderToken: token,
      defenseType,
      defenseName: result.name || defenseType,
      defenseResult: result,
      success: !!result.success,
      action: "defense"
    });
  } catch (error) {
    console.error(`DBU | Erro na macro visual de defesa ${macroName}:`, error);
    ui.notifications.warn(`Erro executando visual de defesa: ${macroName}`);
  }
}

async function dbuRunCombatReactionVisual(actor, reactionType, phase, payload = {}) {
  try {
    const settings = getCombatVisualSettings(actor, reactionType);
    if (settings?.mode !== "custom" || !settings?.macro) return false;
    const macro = game.macros?.getName?.(settings.macro);
    if (!macro) return false;
    const token = (actor.getActiveTokens?.() || [])[0] || null;
    await macro.execute({ actor, token, reactionType, combatReaction:reactionType, phase, action:reactionType, ...payload });
    return true;
  } catch (error) {
    console.warn(`DBU | Visual ${reactionType}/${phase}:`, error);
    return false;
  }
}


// v7.0 — finaliza o ciclo visual do Duel quando todos os participantes
// revelarem os três Clashes. O macro configurado recebe resolve + win/lose/tie.
const DBU_DUEL_VISUAL_RESOLVE_LOCKS = globalThis.DBU_DUEL_VISUAL_RESOLVE_LOCKS || new Set();
globalThis.DBU_DUEL_VISUAL_RESOLVE_LOCKS = DBU_DUEL_VISUAL_RESOLVE_LOCKS;

function dbuDuelParticipants(duelId) {
  const message = game.messages?.contents?.find(entry =>
    entry.getFlag?.(DBU_SYSTEM_ID, "duel")?.duelId === duelId
  ) || null;
  const meta = message?.getFlag?.(DBU_SYSTEM_ID, "duel") || null;
  const defender = meta?.defenderId ? game.actors.get(meta.defenderId) : null;
  const participants = game.actors.filter(actor => !!actor.getFlag?.(DBU_SYSTEM_ID, `duels.${duelId}`));
  const attacker = participants.find(actor => actor.id !== defender?.id && actor.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`)?.role === "attacker") || null;
  const supporters = participants.filter(actor => actor.id !== defender?.id && actor.id !== attacker?.id && actor.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`)?.role === "support");
  return { message, meta, defender, attacker, supporters };
}

function dbuCalculateDuelVisualOutcome(duelId) {
  const { message, defender, attacker, supporters } = dbuDuelParticipants(duelId);
  if (!message || !defender || !attacker) return null;
  const defSt = defender.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`);
  const attSt = attacker.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`);
  const supportRows = supporters.map(actor => ({ actor, st: actor.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`) })).filter(x => x.st);
  if (!defSt?.revealed || !attSt?.revealed || !supportRows.every(x => x.st.revealed)) return null;
  if (attSt?.escaped === "success") return { escaped:true, message, defender, attacker, supporters:supportRows, defSt, attSt };

  const udSupport = supportRows.filter(x => !x.st.uaMode);
  const uaDef = supportRows.filter(x => x.st.uaMode && x.st.side !== "attacker");
  const uaAtt = supportRows.filter(x => x.st.uaMode && x.st.side === "attacker");
  const tier = Number(defender.system.tier || 1);
  const unitedFlat = udSupport.length * tier;
  const sumClash = (rows, i) => rows.reduce((acc, x) => acc + Number(x.st.wagers?.[i] || 0), 0);
  let defWins = 0, attWins = 0;
  const clashes = [];
  for (let i = 0; i < 3; i++) {
    const d = defSt.rolls?.[i], a = attSt.rolls?.[i];
    if (!d || !a) continue;
    const defBoost = unitedFlat + sumClash(udSupport, i) + sumClash(uaDef, i);
    const attBoost = sumClash(uaAtt, i);
    const defTotal = Number(d.total || 0) + defBoost;
    const attTotal = Number(a.total || 0) + attBoost;
    let winner = "tie";
    if (defTotal > attTotal) { winner = "defender"; defWins++; }
    else if (attTotal > defTotal) { winner = "attacker"; attWins++; }
    clashes.push({ index:i + 1, defenderTotal:defTotal, attackerTotal:attTotal, winner, defenderRoll:d, attackerRoll:a, defenderBoost:defBoost, attackerBoost:attBoost });
  }
  let winner = null, loser = null, result = "tie";
  if (defWins >= 2) { winner = defender; loser = attacker; result = "defender"; }
  else if (attWins >= 2) { winner = attacker; loser = defender; result = "attacker"; }
  return { message, defender, attacker, supporters:supportRows, defSt, attSt, clashes, defWins, attWins, winner, loser, result, duelId };
}

async function dbuMaybeRunDuelResolutionVisual(duelId) {
  if (!duelId || DBU_DUEL_VISUAL_RESOLVE_LOCKS.has(duelId)) return false;
  const outcome = dbuCalculateDuelVisualOutcome(duelId);
  if (!outcome || outcome.escaped) return false;
  DBU_DUEL_VISUAL_RESOLVE_LOCKS.add(duelId);
  const payload = { duelId, duelOutcome:outcome, clashes:outcome.clashes, winner:outcome.winner, loser:outcome.loser, defWins:outcome.defWins, attWins:outcome.attWins, result:outcome.result };
  await dbuRunCombatReactionVisual(outcome.defender, "duelClash", "resolve", payload);
  await dbuRunCombatReactionVisual(outcome.attacker, "duelClash", "resolve", payload);
  if (outcome.result === "tie") {
    await dbuRunCombatReactionVisual(outcome.defender, "duelClash", "tie", payload);
    await dbuRunCombatReactionVisual(outcome.attacker, "duelClash", "tie", payload);
  } else {
    await dbuRunCombatReactionVisual(outcome.winner, "duelClash", "win", payload);
    await dbuRunCombatReactionVisual(outcome.loser, "duelClash", "lose", payload);
  }
  return true;
}

function dbuDefenseGifHTML(gifUrl, defenseName) {
  if (!gifUrl) return "";

  return `
    <div
      class="dbu-defense-gif"
      style="
        margin:8px 0 10px 0;
        overflow:hidden;
        border-radius:6px;
        line-height:0;
        text-align:center;
      "
    >
      <img
        src="${dbuEsc(gifUrl)}"
        alt="${dbuEsc(defenseName)}"
        style="
          display:block;
          width:100%;
          max-height:${DBU_DEFENSE_GIF_CONFIG.maxHeight}px;
          object-fit:${DBU_DEFENSE_GIF_CONFIG.objectFit};
          border:0;
        "
      >
    </div>
  `;
}

// ============================================================
// DUEL CLASH v6.5 — INTEGRAÇÃO COM O DUEL NATIVO DO DBU
// ============================================================

const DBU_SYSTEM_ID = "DBU-MRR-OLD";
let DBU_DUEL_HELPER_CACHE = null;

async function dbuGetDuelHelper() {
  if (DBU_DUEL_HELPER_CACHE) return DBU_DUEL_HELPER_CACHE;

  const systemId = game.system?.id || DBU_SYSTEM_ID;

  try {
    DBU_DUEL_HELPER_CACHE = await import(
      `/systems/${systemId}/module/helpers/duel.mjs`
    );
  } catch (error) {
    console.error("DBU | Não foi possível importar duel.mjs:", error);
    throw new Error(
      `Não consegui carregar o Duel nativo do sistema ${systemId}.`
    );
  }

  return DBU_DUEL_HELPER_CACHE;
}

async function dbuGetPreparedAttackSource(actor, sourceKey) {
  const sheet = await dbuPrepareSheet(actor);

  for (const group of (sheet._trackerSourceGroups || [])) {
    if (
      group.label !== "Attack Refs"
      && group.label !== "Sig. Techniques"
    ) {
      continue;
    }

    const source = (group.sources || []).find(
      entry => String(entry.key) === String(sourceKey)
    );

    if (source) {
      return {
        sheet,
        group: group.label,
        source
      };
    }
  }

  return null;
}

function dbuGetDuelContexts(defender) {
  return defender.getFlag("world", "dbuDuelContexts") || {};
}

function dbuGetDuelContext(defender, duelId) {
  return dbuGetDuelContexts(defender)[duelId] || null;
}

async function dbuSetDuelContext(defender, duelId, context) {
  const contexts = foundry.utils.deepClone(
    dbuGetDuelContexts(defender)
  );

  contexts[duelId] = context;

  await defender.setFlag(
    "world",
    "dbuDuelContexts",
    contexts
  );
}

function dbuGetRawTechnique(actor, sourceKey) {
  const key = String(sourceKey || "");
  if (!key.startsWith("tech_")) return null;

  const id = key.slice(5);

  return (actor.system.signatureTechniques || []).find(
    entry => String(entry.id ?? entry._id ?? "") === id
  ) || null;
}

/**
 * Se o ataque original foi liberado por DBU Energy Charge, o source da ficha
 * pode já ter voltado ao número normal de EC. O attackData, porém, preserva
 * o total usado. Acrescentamos apenas a diferença à fórmula do Wound usada
 * pelo Duel nativo.
 */
function dbuIncomingWoundFormula(actor, attack, preparedInfo) {
  const source = preparedInfo?.source;
  const group = preparedInfo?.group || attack.sourceGroup || "";

  let formula = String(
    source?.woundFormula
    || attack.woundFormula
    || "1d10"
  );

  const tier = Number(actor.system.tier || 1);
  const attackEC = Math.max(0, Number(attack.energyCharges || 0));
  const sourceEC = Math.max(0, Number(source?.energyCharges || 0));
  const missingEC = Math.max(0, attackEC - sourceEC);

  if (missingEC > 0) {
    if (group === "Sig. Techniques" || String(attack.sourceKey || "").startsWith("tech_")) {
      const tech = dbuGetRawTechnique(actor, attack.sourceKey);
      const hasMaximumCharge = (tech?.advantages || []).some(
        advantage => String(advantage.name || "").toLowerCase() === "maximum charge"
      );

      const chain = ["d4", "d6", "d8", "d10", "d12"];
      let index = 2;
      if (hasMaximumCharge) index += 1;
      index += Number(actor.system.aptitudes?.energyChargeDiceCategory || 0);
      index += Number(actor.system.aptitudes?.signatureEnergyChargeDiceCategory || 0);
      index = Math.max(0, Math.min(chain.length - 1, index));

      formula = `(${formula})+${missingEC * tier}${chain[index]}`;

      if (String(source?.profile || attack.profile || "").toLowerCase() === "mega flare") {
        formula = `(${formula})+${missingEC * tier}`;
      }
    } else {
      formula = `(${formula})+${missingEC * tier}d6`;
    }
  }

  // Bônus situacional digitado no Ataque v11.2+ também participa da nova
  // rolagem de Wound caso este lado vença o Duel.
  const manual = String(attack.manualWoundTranslated || "").trim();
  if (manual) {
    formula = `(${formula})+(${manual})`;
  }

  // v6.6 — se o ataque normal recebeu United Attack antes do Duel Clash,
  // o Additional Power + Wager desses aliados também acompanha o Wound
  // caso o lado atacante vença o Duel.
  const unitedBonus = Math.max(0, Number(attack.unitedAttackBonus || 0));
  if (unitedBonus > 0) {
    formula = `(${formula})+${unitedBonus}`;
  }

  return formula;
}

async function dbuRecordDuelCounter(defender, source, incomingAttack) {
  const previousCTS = foundry.utils.deepClone(
    defender.system.combatTabState || {}
  );

  const cts = foundry.utils.deepClone(previousCTS);
  const round = dbuGetCurrentRound(defender, cts);

  cts.roundCounterCount =
    (Number(cts.roundCounterCount) || 0) + 1;

  const actionIndex = round.actions.length;

  round.actions.push({
    type: "duel",
    source: "",
    kiCost: Number(source.kiCost || 0),
    dkpCost: 0,
    kiWager: 0,
    description: `Duel: Duel Clash — ${source.name}`,
    duelMode: "clash",
    duelSource: source.key,
    dbuDefenseDuel: true,
    dbuIncomingAttack: incomingAttack?.attackName || ""
  });

  await defender.update({
    "system.combatTabState": cts
  });

  return {
    previousCTS,
    roundNumber: round.roundNumber,
    actionIndex,
    counterNum: cts.roundCounterCount
  };
}

async function dbuBindDuelTrackerAction(defender, tracker, duelId) {
  const cts = foundry.utils.deepClone(
    defender.system.combatTabState || {}
  );

  const round = (cts.rounds || []).find(
    entry => Number(entry.roundNumber) === Number(tracker.roundNumber)
  );

  const action = round?.actions?.[tracker.actionIndex];
  if (!action?.dbuDefenseDuel) return;

  action.dbuDuelId = duelId;

  await defender.update({
    "system.combatTabState": cts
  });
}

async function dbuRefundDuelCounter(defender, context) {
  if (!defender || !context) return;

  const cts = foundry.utils.deepClone(
    defender.system.combatTabState || {}
  );

  const round = (cts.rounds || []).find(
    entry => Number(entry.roundNumber) === Number(context.counterRound)
  );

  const preferredIndex = Number(context.counterActionIndex);
  let index = (round?.actions || []).findIndex(action =>
    action?.dbuDefenseDuel
    && String(action?.dbuDuelId || "") === String(context.duelId || "")
  );

  if (index < 0) {
    const fallback = round?.actions?.[preferredIndex];
    if (fallback?.dbuDefenseDuel) index = preferredIndex;
  }

  let refunded = false;

  if (index >= 0 && round?.actions?.[index]) {
    round.actions.splice(index, 1);
    refunded = true;
  }

  if (refunded) {
    cts.roundCounterCount = Math.max(
      0,
      (Number(cts.roundCounterCount) || 0) - 1
    );
  }

  await defender.update({
    "system.combatTabState": cts
  });

  console.log(
    `DBU | Counter Action devolvida após Duel Escape: ${defender.name}`
  );
}

async function dbuChooseDuelInitiatingAttack(defender, attack) {
  const sheet = await dbuPrepareSheet(defender);
  const list = [];
  let options = "";

  for (const group of (sheet._trackerSourceGroups || [])) {
    if (
      group.label !== "Attack Refs"
      && group.label !== "Sig. Techniques"
    ) {
      continue;
    }

    if (!(group.sources || []).length) continue;

    options += `<optgroup label="${dbuEsc(group.label)}">`;

    for (const source of group.sources) {
      const index = list.length;
      list.push({ group: group.label, source });

      const chips = [
        source.foundation || "",
        source.energyCharges ? `EC ${source.energyCharges}` : "",
        source.powerShot ? `PS ${source.powerShot}` : "",
        source.kiCost ? `${source.kiCost} KP` : "0 KP"
      ].filter(Boolean).join(" · ");

      options += `
        <option value="${index}">
          ${dbuEsc(source.name)}${chips ? ` — ${dbuEsc(chips)}` : ""}
        </option>
      `;
    }

    options += "</optgroup>";
  }

  if (!list.length) {
    ui.notifications.warn(
      `${defender.name}: nenhum ataque disponível para iniciar Duel Clash.`
    );
    return null;
  }

  const choice = await Dialog.wait({
    title: `${defender.name} — Duel Clash`,
    content: `
      <div class="dbu-duel-defense-dialog">
        <p>
          Ataque recebido:
          <b>${dbuEsc(attack.attackerName || "Atacante")} — ${dbuEsc(attack.attackName || "Attack")}</b>
        </p>

        <div class="form-group">
          <label><b>Initiating Attack</b></label>
          <select id="dbu-duel-source" style="width:100%;">
            ${options}
          </select>
        </div>

        <p class="notes">
          O Initiating Attack gasta seu KP normalmente e o Duel usa uma Counter Action.
          O atacante original poderá escolher <b>Accept Duel</b> ou <b>Duel Escape</b>.
        </p>
      </div>
    `,
    buttons: {
      duel: {
        icon: '<i class="fas fa-bolt"></i>',
        label: "Iniciar Duel Clash",
        callback: html => Number(html.find("#dbu-duel-source").val())
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: "Cancelar",
        callback: () => null
      }
    },
    default: "duel",
    close: () => null
  });

  if (choice === null || choice === undefined) return null;
  return list[choice] || null;
}

function dbuAttackAllowsDuel(defender, attack) {
  if (!defender || !attack) return false;
  const group = String(attack.sourceGroup || attack.group || "").toLowerCase();
  const name = String(attack.attackName || attack.name || "").toLowerCase();
  const signature = !!attack.isSignature
    || group.includes("sig")
    || group.includes("signature")
    || name.includes("signature technique");
  const charges = Math.max(
    0,
    Number(attack.energyCharges || 0),
    Number(attack.energyChargeGathered || 0),
    Number(attack.gatheredCharges || 0)
  );
  const wager = Math.max(0, Number(attack.kiWager ?? attack.wager ?? 0));
  const attacker = attack?.attackerId ? game.actors?.get?.(attack.attackerId) : null;
  const baseTier = Math.max(1, Number(
    attack?.attackerBaseTier
    ?? attack?.baseTier
    ?? attacker?.system?.baseTier
    ?? attacker?.system?.tier
    ?? 1
  ));
  return signature || charges >= 2 || wager >= (10 * baseTier);
}

async function dbuInitiateDuelClash(defender, attack, message) {
  if (!dbuAttackAllowsDuel(defender, attack)) {
    ui.notifications.warn(`${defender?.name || "Defensor"}: este ataque não atende aos requisitos do Duel Maneuver.`);
    return { cancelled: true, reason: "duel-not-eligible" };
  }
  const selected = await dbuChooseDuelInitiatingAttack(defender, attack);
  if (!selected) return { cancelled: true };

  const source = selected.source;
  const cost = Math.max(0, Number(source.kiCost || 0));

  await dbuRunCombatReactionVisual(defender, "duelClash", "start", {
    attack, message, source, attacker: game.actors.get(attack.attackerId)
  });

  const payment = await dbuPayKiAndCapacity(
    defender,
    cost,
    `Duel Clash — ${source.name}`
  );

  if (!payment.ok) return { cancelled: true };

  let tracker = null;
  const oldMessages = new Set(
    game.messages.contents.map(entry => entry.id)
  );

  try {
    tracker = await dbuRecordDuelCounter(
      defender,
      source,
      attack
    );

    const helper = await dbuGetDuelHelper();

    await helper.initiateDuel(defender, {
      mode: "clash",
      sourceName: source.name,
      foundation: source.foundation || "",
      ec: Number(source.energyCharges || 0),
      ps: Number(source.powerShot || 0),
      woundFormula: source.woundFormula || "1d10",
      damageCat: source.damageCat || "Standard"
    });

    let duelMessage = null;

    for (let attempt = 0; attempt < 20; attempt++) {
      duelMessage = game.messages.contents
        .slice()
        .reverse()
        .find(entry => {
          if (oldMessages.has(entry.id)) return false;
          const meta = entry.getFlag(DBU_SYSTEM_ID, "duel");
          return meta?.defenderId === defender.id;
        });

      if (duelMessage) break;
      await dbuSleep(50);
    }

    const duelMeta = duelMessage?.getFlag(
      DBU_SYSTEM_ID,
      "duel"
    );

    if (!duelMeta?.duelId) {
      throw new Error(
        "O DBU não criou a carta nativa do Duel."
      );
    }

    const duelId = duelMeta.duelId;

    await dbuBindDuelTrackerAction(
      defender,
      tracker,
      duelId
    );

    const context = {
      version: DBU_INIT_VERSION,
      duelId,
      originalAttackMessageId: message?.id || null,
      defenderId: defender.id,
      attackerId: attack.attackerId,
      defenderSourceKey: source.key,
      defenderSourceName: source.name,
      counterRound: tracker.roundNumber,
      counterActionIndex: tracker.actionIndex,
      counterNum: tracker.counterNum,
      sourceCost: cost,
      createdAt: Date.now(),
      attack: foundry.utils.deepClone(attack)
    };

    await dbuSetDuelContext(
      defender,
      duelId,
      context
    );

    // v6.6 — avisa a carta do ataque. Em multi-target, os outros alvos
    // passam a poder escolher Join United Duel no lugar de iniciar outro Duel.
    await dbuAnnounceDuelOnAttackCard(
      message,
      defender,
      duelId,
      source.name
    );

    console.log(
      "DBU | Duel Clash iniciado pela defesa",
      context
    );

    return {
      status: "duel",
      text:
        `⚡ Duel Clash — ${source.name} vs ${attack.attackName} · ` +
        `resolva na carta DUEL`,
      duelId
    };
  } catch (error) {
    console.error("DBU | Iniciar Duel Clash:", error);

    // Se algo falhar depois do pagamento, devolve o custo e restaura o tracker.
    try {
      const currentKi = Number(defender.system.kiPool?.value || 0);
      const capacity = dbuGetCapacity(defender);

      const updates = {
        "system.kiPool.value": currentKi + cost,
        "system.status.capacitySpent": Math.max(0, capacity.spent - cost)
      };

      if (tracker?.previousCTS) {
        updates["system.combatTabState"] = tracker.previousCTS;
      }

      await defender.update(updates);
    } catch (refundError) {
      console.error("DBU | Falha devolvendo custo do Duel:", refundError);
    }

    ui.notifications.error(
      error.message || "Erro iniciando Duel Clash."
    );

    return { cancelled: true };
  }
}

async function dbuSetupIncomingDuelAttacker(
  attacker,
  defender,
  duelId,
  context,
  { escaped = null } = {}
) {
  const attack = context.attack || {};
  const helper = await dbuGetDuelHelper();

  // Garante que métodos internos usados por computeDuelSide já estão preparados.
  await dbuPrepareSheet(attacker);

  const prepared = await dbuGetPreparedAttackSource(
    attacker,
    attack.sourceKey
  );

  const side = helper.computeDuelSide(attacker, {
    mode: "clash",
    ec: Number(attack.energyCharges || 0),
    ps: Number(attack.powerShot || 0),
    foundation: attack.foundation || prepared?.source?.foundation || ""
  });

  const woundFormula = dbuIncomingWoundFormula(
    attacker,
    attack,
    prepared
  );

  await attacker.setFlag(
    DBU_SYSTEM_ID,
    `duels.${duelId}`,
    {
      role: "attacker",
      escaped,
      mode: "clash",
      sourceName: attack.attackName || prepared?.source?.name || "Attack",
      foundation: attack.foundation || prepared?.source?.foundation || "",
      ec: Number(attack.energyCharges || 0),
      ps: Number(attack.powerShot || 0),
      woundFormula,
      damageCat: attack.damageCat || attack.damageCategory || prepared?.source?.damageCat || "Standard",
      dice: side.dice,
      mod: side.mod,
      breakdown: side.breakdown,
      woundCT: side.woundCT,
      wagerCap: side.wagerCap,
      wagers: [0, 0, 0],
      revealed: false,
      rolls: null,
      dbuOriginalIncomingAttack: true,
      dbuOriginalAttackMessageId: context.originalAttackMessageId || null
    }
  );

  return {
    sourceName: attack.attackName || "Attack",
    woundFormula
  };
}

function dbuDuelContextFromButton(button) {
  const shell = button.closest?.(".dbu-duel-shell");
  const duelId = shell?.dataset?.duelId;
  if (!duelId) return null;

  const messageElement = button.closest?.("[data-message-id]");
  let message = messageElement?.dataset?.messageId
    ? game.messages.get(messageElement.dataset.messageId)
    : null;

  if (!message) {
    message = game.messages.contents.find(entry =>
      entry.getFlag(DBU_SYSTEM_ID, "duel")?.duelId === duelId
    ) || null;
  }

  const meta = message?.getFlag(DBU_SYSTEM_ID, "duel");
  if (!meta?.defenderId) return null;

  const defender = game.actors.get(meta.defenderId);
  if (!defender) return null;

  const context = dbuGetDuelContext(defender, duelId);
  if (!context) return null;

  return {
    duelId,
    message,
    defender,
    context
  };
}

// ============================================================
// INJETAR "DUEL CLASH" NA CARTA DE DEFESA
// ============================================================

function dbuInjectDuelClashButton(message, html) {
  const attack = message.getFlag("world", "dbuAttackData");
  if (!attack) return;
  // Reflect já é um Out-of-Sequence Maneuver com Wound vindo do atacante
  // original. O Duel Clash nativo espera um Initiating Attack existente na
  // ficha do atacante atual, então ele não é oferecido nesta carta especial.
  if (attack.isReflect) return;

  const activeDuel = message.getFlag("world", "dbuActiveDuel") || null;

  const root = html instanceof HTMLElement
    ? html
    : (html?.[0] || html);

  if (!root?.querySelectorAll) return;

  const rows = root.querySelectorAll(".dbu-area-target");

  for (const row of rows) {
    const actions = row.querySelector(".dbu-attack-actions");
    if (!actions) continue;

    const anyDefense = actions.querySelector("[data-defender-id]");
    const defenderId = anyDefense?.dataset?.defenderId;
    if (!defenderId) continue;
    const defender = game.actors.get(defenderId);

    // Duel é contextual: só existe contra Signature Technique, ataque com 2+
    // Energy Charges ou Ki Wager de 10(bT)+. Não deixa botão genérico no card.
    if (!dbuAttackAllowsDuel(defender, attack)) {
      actions
        .querySelectorAll('[data-dbu-defense-v5="duelClash"], [data-dbu-united-duel-v1]')
        .forEach(button => button.remove());
      continue;
    }

    // Se já existe um Duel proveniente deste ataque e este é outro co-target,
    // troca somente a opção Duel Clash por Join United Duel. As demais
    // defesas continuam disponíveis normalmente.
    if (
      activeDuel?.duelId
      && defenderId !== activeDuel.primaryDefenderId
      && (attack.targetActorIds || []).includes(defenderId)
    ) {
      actions
        .querySelectorAll('[data-dbu-defense-v5="duelClash"]')
        .forEach(button => button.remove());

      if (!actions.querySelector("[data-dbu-united-duel-v1]")) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "dbu-pay-btn dbu-united-duel-btn";
        button.dataset.dbuUnitedDuelV1 = "1";
        button.dataset.defenderId = defenderId;
        button.dataset.duelId = activeDuel.duelId;
        button.dataset.primaryDefenderId = activeDuel.primaryDefenderId;
        button.innerHTML = '<i class="fas fa-hands-helping"></i> Join United Duel';
        button.title = "Co-target: entre no Duel do alvo principal como United Duel.";
        actions.appendChild(button);
      }

      continue;
    }

    if (actions.querySelector('[data-dbu-defense-v5="duelClash"]')) {
      continue;
    }

    // O alvo principal de um Duel já iniciado não recebe outro botão.
    if (
      activeDuel?.duelId
      && defenderId === activeDuel.primaryDefenderId
    ) {
      continue;
    }

    const button = document.createElement("button");
    button.type = "button";
    button.className = "dbu-pay-btn dbu-duel-defense-btn";
    button.dataset.dbuDefenseV5 = "duelClash";
    button.dataset.defenderId = defenderId;
    button.innerHTML = '<i class="fas fa-bolt"></i> Duel Clash';
    button.title = "Use a Counter Action e um Initiating Attack para iniciar um Duel Clash.";

    actions.appendChild(button);
  }
}
const duelInjectHookId = Hooks.on(
  "renderChatMessage",
  (message, html) => {
    try {
      dbuInjectDuelClashButton(message, html);
    } catch (error) {
      console.error("DBU | Injetar Duel Clash:", error);
    }
  }
);

globalThis.DBU_BOOTSTRAP.duelInjectHookId =
  duelInjectHookId;

// ============================================================
// ACCEPT DUEL — USA AUTOMATICAMENTE O ATAQUE ORIGINAL
// ============================================================

const dbuDuelAcceptHandler = async event => {
  const button = event.target.closest?.(".dbu-duel-accept");
  if (!button) return;

  const info = dbuDuelContextFromButton(button);

  // Duel iniciado normalmente pela ficha: deixa o comportamento nativo intacto.
  if (!info) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  const attacker = game.actors.get(info.context.attackerId);

  if (!attacker) {
    return ui.notifications.error(
      "Atacante original do Duel não encontrado."
    );
  }

  if (!game.user.isGM && !attacker.isOwner) {
    return ui.notifications.warn(
      `Somente quem controla ${attacker.name} pode aceitar este Duel.`
    );
  }

  button.disabled = true;

  try {
    const current = attacker.getFlag(
      DBU_SYSTEM_ID,
      `duels.${info.duelId}`
    );

    if (current?.role === "attacker") return;

    const setup = await dbuSetupIncomingDuelAttacker(
      attacker,
      info.defender,
      info.duelId,
      info.context,
      { escaped: null }
    );

    await dbuRunCombatReactionVisual(attacker, "duelClash", "accept", {
      duelId:info.duelId, defender:info.defender, context:info.context, setup
    });
    await dbuRunCombatReactionVisual(info.defender, "duelClash", "accept", {
      duelId:info.duelId, attacker, context:info.context, setup
    });

    ui.notifications.info(
      `${attacker.name} aceita o Duel com ${setup.sourceName}.`
    );
  } catch (error) {
    console.error("DBU | Accept Duel:", error);
    button.disabled = false;
    ui.notifications.error(
      error.message || "Erro aceitando o Duel."
    );
  }
};

document.addEventListener(
  "click",
  dbuDuelAcceptHandler,
  true
);

globalThis.DBU_BOOTSTRAP.duelAcceptHandler =
  dbuDuelAcceptHandler;

// ============================================================
// DUEL ESCAPE — FORÇA O ATACANTE ORIGINAL
// ============================================================

async function dbuRequestDuelCounterRefund(defender, duelId, context) {
  const payload = {
    type: "dbuRefundDuelCounter",
    defenderId: defender.id,
    duelId,
    userId: game.user.id
  };

  if (game.user.isGM) {
    await dbuGMRefundDuelCounter(payload);
  } else {
    game.socket.emit(DBU_SOCKET, payload);
  }
}

const dbuDuelEscapeHandler = async event => {
  const button = event.target.closest?.(".dbu-duel-escape");
  if (!button) return;

  const info = dbuDuelContextFromButton(button);
  if (!info) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  const attacker = game.actors.get(info.context.attackerId);
  if (!attacker) {
    return ui.notifications.error(
      "Atacante original do Duel não encontrado."
    );
  }

  if (!game.user.isGM && !attacker.isOwner) {
    return ui.notifications.warn(
      `Somente quem controla ${attacker.name} pode tentar Duel Escape.`
    );
  }

  button.disabled = true;

  try {
    const mine = new Roll(
      `1d10+${Number(attacker.system.savingThrows?.impulsive?.bonus || 0)}`
    );

    const theirs = new Roll(
      `1d10+${Number(info.defender.system.savingThrows?.impulsive?.bonus || 0)}`
    );

    await mine.evaluate();
    await theirs.evaluate();

    const success = Number(mine.total || 0) > Number(theirs.total || 0);

    await dbuRunCombatReactionVisual(attacker, "duelClash", success ? "escape-success" : "escape-fail", {
      duelId:info.duelId, defender:info.defender, context:info.context,
      success, attackerRoll:mine, defenderRoll:theirs
    });
    await dbuRunCombatReactionVisual(info.defender, "duelClash", success ? "escape-success" : "escape-fail", {
      duelId:info.duelId, attacker, context:info.context,
      success, attackerRoll:mine, defenderRoll:theirs
    });

    if (success) {
      await attacker.setFlag(
        DBU_SYSTEM_ID,
        `duels.${info.duelId}`,
        {
          role: "attacker",
          escaped: "success"
        }
      );

      await dbuRequestDuelCounterRefund(
        info.defender,
        info.duelId,
        info.context
      );
    } else {
      await dbuSetupIncomingDuelAttacker(
        attacker,
        info.defender,
        info.duelId,
        info.context,
        { escaped: "failed" }
      );
    }

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: attacker }),
      content: `
        <div class="dbu-round-card">
          <div class="dbu-round-num">
            <i class="fas fa-running"></i>
            ${success ? "ESC" : "FAIL"}
          </div>
          <div class="dbu-round-info">
            <span class="dbu-round-title">
              Duel Escape — ${dbuEsc(attacker.name)}
            </span>
            <span class="dbu-round-detail">
              Impulsive ${mine.total} vs ${theirs.total} —
              ${
                success
                  ? "escapou! Ataque anulado e Counter Action devolvida."
                  : `falhou — o Duel continua usando ${dbuEsc(info.context.attack?.attackName || "o ataque original")}.`
              }
            </span>
          </div>
        </div>
      `
    });
  } catch (error) {
    console.error("DBU | Duel Escape:", error);
    button.disabled = false;
    ui.notifications.error(
      error.message || "Erro no Duel Escape."
    );
  }
};

document.addEventListener(
  "click",
  dbuDuelEscapeHandler,
  true
);

globalThis.DBU_BOOTSTRAP.duelEscapeHandler =
  dbuDuelEscapeHandler;

// ============================================================
// KI WAGER DO DUEL TAMBÉM CONSOME CAPACITY
// ============================================================

const dbuDuelRevealHandler = async event => {
  const button = event.target.closest?.(".dbu-duel-reveal");
  if (!button) return;

  const shell = button.closest?.(".dbu-duel-shell");
  const duelId = shell?.dataset?.duelId;
  const actorId = button.dataset.actorId;

  if (!duelId || !actorId) return;

  const actor = game.actors.get(actorId);
  if (!actor?.isOwner && !game.user.isGM) return;

  const state = actor?.getFlag(
    DBU_SYSTEM_ID,
    `duels.${duelId}`
  );

  if (!state || state.revealed) return;

  await dbuRunCombatReactionVisual(actor, "duelClash", "reveal", {
    duelId, duelState:foundry.utils.deepClone(state)
  });

  const wagers = (state.wagers || [0, 0, 0]).map(
    value => Math.max(0, Number(value) || 0)
  );

  const spent = wagers.reduce((a, b) => a + b, 0);
  if (spent <= 0) {
    // O handler nativo ainda fará o Reveal. Aguarda a gravação para disparar
    // resolve/win/lose/tie mesmo quando não existe Ki Wager.
    (async () => {
      for (let attempt = 0; attempt < 30; attempt++) {
        await dbuSleep(50);
        const afterState = actor.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`);
        if (afterState?.revealed) { await dbuMaybeRunDuelResolutionVisual(duelId); break; }
      }
    })();
    return;
  }

  // Replica a validação do helper nativo antes de permitir o click.
  let overCap = false;

  if (state.role === "support" && state.uaMode) {
    overCap = wagers.some(value => value > Number(state.wagerCap || 0));
  } else {
    overCap = spent > Number(state.wagerCap || 0);
  }

  if (overCap) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    return ui.notifications.warn(
      `${actor.name}: Ki Wager acima do limite do Duel.`
    );
  }

  const ki = Number(actor.system.kiPool?.value || 0);
  const capacity = dbuGetCapacity(actor);

  if (ki < spent) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    return ui.notifications.warn(
      `${actor.name}: Ki insuficiente para ${spent} KP de Wager.`
    );
  }

  if (capacity.max > 0 && capacity.left < spent) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    return ui.notifications.warn(
      `${actor.name}: Capacity insuficiente para ${spent} KP de Wager.`
    );
  }

  const key = `${duelId}:${actor.id}`;
  if (globalThis.DBU_DUEL_WAGER_LOCKS.has(key)) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    return;
  }
  globalThis.DBU_DUEL_WAGER_LOCKS.add(key);

  // Não bloqueia o handler nativo. Espera o estado "revealed" ser salvo e só
  // então espelha o custo na Capacity.
  (async () => {
    try {
      let revealed = false;

      for (let attempt = 0; attempt < 30; attempt++) {
        await dbuSleep(50);

        const afterState = actor.getFlag(
          DBU_SYSTEM_ID,
          `duels.${duelId}`
        );

        if (afterState?.revealed) {
          revealed = true;
          break;
        }
      }

      if (!revealed) {
        globalThis.DBU_DUEL_WAGER_LOCKS.delete(key);
        return;
      }

      await dbuMaybeRunDuelResolutionVisual(duelId);

      const afterCapacity = dbuGetCapacity(actor);

      await actor.update({
        "system.status.capacitySpent":
          afterCapacity.spent + spent
      });

      const finalCapacity = dbuGetCapacity(actor);

      const whisperIds = game.users
        .filter(user =>
          user.isGM
          || actor.testUserPermission(user, "OWNER")
        )
        .map(user => user.id);

      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        whisper: whisperIds,
        content: `
          <div class="dbu-ki-deduct">
            <b>${dbuEsc(actor.name)}</b><br>
            Duel Ki Wager: <b>-${spent} KP / Capacity</b><br>
            Capacity Spent:
            <b>${afterCapacity.spent} → ${finalCapacity.spent}</b><br>
            Capacity restante:
            <b>${finalCapacity.left} / ${finalCapacity.max}</b>
          </div>
        `
      });
    } catch (error) {
      console.error("DBU | Capacity do Duel Wager:", error);
      globalThis.DBU_DUEL_WAGER_LOCKS.delete(key);
    }
  })();
};

document.addEventListener(
  "click",
  dbuDuelRevealHandler,
  true
);

globalThis.DBU_BOOTSTRAP.duelRevealHandler =
  dbuDuelRevealHandler;

// ============================================================
// CAPACITY
// ============================================================

function dbuGetCapacity(actor) {
  const max = Number(
    actor.system.status?.maxCapacity || 0
  );

  const spent = Number(
    actor.system.status?.capacitySpent || 0
  );

  return {
    max,
    spent,
    left: Math.max(0, max - spent)
  };
}

// ============================================================
// VALIDAR KI + CAPACITY ANTES DE UMA AÇÃO
// ============================================================

function dbuCheckAffordability(
  actor,
  amount,
  label = "Ação",
  notify = true
) {
  amount = Math.max(0, Number(amount) || 0);

  const currentKi = Math.max(0, Number(
    actor?.system?.kiPool?.value || 0
  ));

  const capacity = dbuGetCapacity(actor);

  if (amount <= 0) {
    return {
      ok: true,
      amount: 0,
      ki: currentKi,
      ...capacity
    };
  }

  if (currentKi < amount) {
    if (notify) {
      ui.notifications.warn(
        `${actor.name}: Ki insuficiente para ${label}. ` +
        `Disponível ${currentKi}, necessário ${amount} KP.`
      );
    }

    return {
      ok: false,
      reason: "ki",
      amount,
      ki: currentKi,
      ...capacity
    };
  }

  if (
    capacity.max > 0
    && capacity.left < amount
  ) {
    if (notify) {
      ui.notifications.warn(
        `${actor.name}: Capacity insuficiente para ${label}. ` +
        `Restante ${capacity.left}, necessário ${amount}.`
      );
    }

    return {
      ok: false,
      reason: "capacity",
      amount,
      ki: currentKi,
      ...capacity
    };
  }

  return {
    ok: true,
    amount,
    ki: currentKi,
    ...capacity
  };
}

// ============================================================
// PAGAR KI + CAPACITY
// ============================================================

async function dbuPayKiAndCapacity(
  actor,
  amount,
  label = "Ação"
) {
  amount = Math.max(
    0,
    Number(amount) || 0
  );

  if (!amount) {
    return {
      ok: true,
      amount: 0,
      capacityLeft: dbuGetCapacity(actor).left
    };
  }

  const currentKi = Number(
    actor.system.kiPool?.value || 0
  );

  const capacity = dbuGetCapacity(actor);

  if (currentKi < amount) {
    ui.notifications.warn(
      `${actor.name}: Ki insuficiente. Necessário ${amount} KP.`
    );

    return {
      ok: false,
      reason: "ki"
    };
  }

  if (
    capacity.max > 0 &&
    capacity.left < amount
  ) {
    ui.notifications.warn(
      `${actor.name}: Capacity insuficiente. ` +
      `Restante ${capacity.left}, necessário ${amount}.`
    );

    return {
      ok: false,
      reason: "capacity"
    };
  }

  await actor.update({
    "system.kiPool.value":
      currentKi - amount,

    "system.status.capacitySpent":
      capacity.spent + amount
  });

  const after = dbuGetCapacity(actor);

  console.log(
    "DBU | Pagamento Ki + Capacity",
    {
      actor: actor.name,
      label,
      amount,
      kiBefore: currentKi,
      kiAfter: currentKi - amount,
      capacityBefore: capacity.spent,
      capacityAfter: after.spent,
      capacityMax: after.max
    }
  );

  return {
    ok: true,
    amount,
    ki: currentKi - amount,
    capacitySpent: after.spent,
    capacityLeft: after.left
  };
}

// ============================================================
// ROUND TRACKER
// ============================================================

function dbuGetCurrentRound(actor, cts) {
  cts.rounds ??= [];

  if (!cts.rounds.length) {
    cts.rounds.push({
      roundNumber: 1,
      actions: []
    });
  }

  const round = cts.rounds[cts.rounds.length - 1];

  round.actions ??= [];
  round.roundNumber ??= cts.rounds.length;
  cts.currentRound = round.roundNumber;

  return round;
}

// ============================================================
// REGISTRAR DEFESA
// ============================================================

async function dbuRecordDefend(
  actor,
  defenseType,
  {
    penaltyRanks = 0,
    wager = 0,
    incomingEC = 0
  } = {}
) {
  const cts = foundry.utils.deepClone(
    actor.system.combatTabState || {}
  );

  const round = dbuGetCurrentRound(
    actor,
    cts
  );

  const tier = Number(
    actor.system.tier || 1
  );

  const names = {
    parry: "Parry",
    directHit: "Direct Hit",
    powerFlare: "Power Flare",
    crossCounter: "Cross Counter",
    guard: "Guard"
  };

  const baseCosts = {
    parry: 0,
    directHit: 0,
    powerFlare: 2 * tier,
    crossCounter: 2 * tier,
    guard: 8 * tier
  };

  cts.roundCounterCount =
    (Number(cts.roundCounterCount) || 0) + 1;

  round.actions.push({
    type: "defend",
    source: "",
    kiCost: baseCosts[defenseType] || 0,
    dkpCost: 0,
    kiWager: 0,
    description: `Defend: ${names[defenseType] || defenseType}`,
    defendOption: defenseType,
    defendPenalty: Math.max(
      0,
      Number(penaltyRanks) || 0
    ),
    defendWager: Math.max(
      0,
      Number(wager) || 0
    ),
    defendEC: Math.max(
      0,
      Number(incomingEC) || 0
    )
  });

  await actor.update({
    "system.combatTabState": cts
  });

  return cts.roundCounterCount;
}

// ============================================================
// CRITICAL EXTRA
// ============================================================

async function dbuCritRoll(actor, sheet) {
  if (
    typeof sheet._critExtraFormula !== "function"
  ) {
    return null;
  }

  const tier = Number(
    actor.system.tier || 1
  );

  let formula = null;

  try {
    formula = sheet._critExtraFormula(tier);
  } catch {
    try {
      formula = sheet._critExtraFormula();
    } catch {
      formula = null;
    }
  }

  if (!formula) return null;

  const roll = new Roll(formula);
  await roll.evaluate();

  return roll;
}

// ============================================================
// DODGE
// ============================================================

async function dbuRollDodge(defender, { silent = false } = {}) {
  const sheet = await dbuPrepareSheet(defender);

  const td = sheet._trackerDodge || {
    formula: "1d10",
    ct: 10
  };

  const baseTier = Number(
    defender.system.baseTier ||
    defender.system.tier ||
    1
  );

  const currentCount = Number(
    defender.system.combatTabState
      ?.roundDodgeCount || 0
  );

  const dodgeNum = currentCount + 1;
  const perStack = Math.ceil(baseTier / 2);
  const penalty = (dodgeNum - 1) * perStack;

  const formula = penalty > 0
    ? `(${td.formula})-${penalty}`
    : String(td.formula);

  const roll = new Roll(formula);
  await roll.evaluate();

  const rawNatural = Number(
    roll.dice?.[0]
      ?.results?.[0]
      ?.result || 0
  );

  const naturalBonus = Number(
    defender.system
      ._bestialDodgeNaturalBonus || 0
  );

  const natural = Math.min(
    10,
    rawNatural + naturalBonus
  );

  const critical =
    natural >= Number(td.ct || 10);

  const botch = rawNatural === 1;

  let critRoll = null;

  if (critical) {
    critRoll = await dbuCritRoll(
      defender,
      sheet
    );
  }

  const total =
    Number(roll.total || 0)
    + (natural - rawNatural)
    + Number(critRoll?.total || 0)
    - (botch ? 2 * baseTier : 0);

  await defender.update({
    "system.combatTabState.roundDodgeCount":
      dodgeNum,

    "system.tracking.diminishingDefense":
      dodgeNum - 1
  });

  if (!silent) await roll.toMessage({
    speaker: ChatMessage.getSpeaker({
      actor: defender
    }),

    flavor: `
      <div class="dbu-attack-roll dbu-dodge-card">
        <h3 class="dbu-attack-title">
          <span class="dbu-card-title-text">
            ${dbuEsc(defender.name)} — Dodge
          </span>
          <span class="dbu-action-count">
            DGE ${dodgeNum}
          </span>
        </h3>

        <div class="dbu-card-body">
          <div class="dbu-roll-row">
            <span class="dbu-roll-label">Dodge</span>

            <span class="dbu-roll-main">
              <code class="dbu-roll-formula">
                ${dbuEsc(formula)}
              </code>

              <span class="dbu-roll-sub">
                Nat ${natural} · CT ${td.ct}+
              </span>
            </span>

            <span class="dbu-roll-total">
              ${total}
            </span>
          </div>
        </div>
      </div>
    `
  });

  return {
    total,
    natural,
    critical,
    botch
  };
}

// ============================================================
// PARRY / POWER FLARE
// ============================================================

async function dbuRollDefend(
  defender,
  type,
  attack,
  wager = 0,
  { silent = false } = {}
) {
  const sheet = await dbuPrepareSheet(defender);

  const tier = Number(
    defender.system.tier || 1
  );

  const baseTier = Number(
    defender.system.baseTier || tier
  );

  const isParry = type === "parry";

  let strikeCT = 10;
  let woundCT = 10;

  if (
    typeof sheet._calcCombatCTs === "function"
  ) {
    const calculated = sheet._calcCombatCTs(
      defender.system
    );

    strikeCT = Number(
      calculated?.strikeCT || 10
    );

    woundCT = Number(
      calculated?.woundCT || 10
    );
  }

  const rollCT = isParry
    ? strikeCT
    : woundCT;

  const penaltyRanks = isParry
    ? Math.max(
        0,
        Number(attack.energyCharges || 0)
      )
      + Math.max(
        0,
        Number(attack.powerShot || 0)
      )
    : 0;

  const penalty = penaltyRanks * tier;

  const baseFormula = isParry
    ? (
        sheet._trackerDefend
          ?.strikeFormula ||
        "1d10"
      )
    : (
        sheet._trackerDefend
          ?.woundFormula ||
        "1d10"
      );

  let formula = String(baseFormula);

  if (penalty > 0) {
    formula = `(${formula})-${penalty}`;
  }

  if (!isParry && wager > 0) {
    formula = `(${formula})+${wager}`;
  }

  const cyberParry = Number(
    defender.system._cyberParryStrike
    ?? defender.system._cyberParryStrikeBonus
    ?? 0
  );

  const fierceCounter = Number(
    defender.system.aptitudes
      ?.fierceCounterStrike
    ?? defender.system.aptitudes
      ?.fierceCounterStrikeBonus
    ?? 0
  );

  const parryBonus = isParry
    ? cyberParry + fierceCounter
    : 0;

  if (parryBonus) {
    formula = `(${formula})+${parryBonus}`;
  }

  const counterNum = await dbuRecordDefend(
    defender,
    type,
    {
      penaltyRanks,
      wager,
      incomingEC: attack.energyCharges
    }
  );

  const roll = new Roll(formula);
  await roll.evaluate();

  const natural = Number(
    roll.dice?.[0]
      ?.results?.[0]
      ?.result || 0
  );

  const critical = natural >= rollCT;
  const botch = natural === 1;

  let critRoll = null;

  if (critical) {
    critRoll = await dbuCritRoll(
      defender,
      sheet
    );
  }

  const total =
    Number(roll.total || 0)
    + Number(critRoll?.total || 0)
    - (botch ? 2 * baseTier : 0);

  const name = isParry
    ? "Parry"
    : "Power Flare";

  if (!silent) await roll.toMessage({
    speaker: ChatMessage.getSpeaker({
      actor: defender
    }),

    flavor: `
      <div class="dbu-attack-roll dbu-defend-card">
        <h3 class="dbu-attack-title">
          <span class="dbu-card-title-text">
            ${dbuEsc(defender.name)} — ${name}
          </span>

          <span class="dbu-action-count">
            CTR ${counterNum}
          </span>
        </h3>

        <div class="dbu-card-body">
          <div class="dbu-roll-row">
            <span class="dbu-roll-label">
              ${name}
            </span>

            <span class="dbu-roll-main">
              <code class="dbu-roll-formula">
                ${dbuEsc(formula)}
              </code>

              <span class="dbu-roll-sub">
                Nat ${natural} · CT ${rollCT}+
              </span>
            </span>

            <span class="dbu-roll-total">
              ${total}
            </span>
          </div>
        </div>
      </div>
    `
  });

  return {
    total,
    counterNum,
    penaltyRanks
  };
}

// ============================================================
// DAMAGE
// ============================================================

async function dbuApplyDamage(
  defender,
  attack,
  defense = "none"
) {
  const sheet = defender.sheet;

  if (!sheet) {
    throw new Error(
      "Ficha do defensor não encontrada."
    );
  }

  const rawCategory = String(
    attack.damageCategory
    || attack.damageCat
    || "standard"
  ).toLowerCase();

  let category = "standard";

  if (rawCategory.includes("direct")) {
    category = "direct";
  } else if (rawCategory.includes("lethal")) {
    category = "lethal";
  }

  // Terrain Lift 0.9.2 — Shielding é automático quando o personagem é atingido.
  // A redução altera o Dice Score do Wound ANTES do cálculo nativo de Damage.
  const terrainShield = prepareTerrainShield(
    defender,
    Math.max(0, Number(attack.woundTotal || 0))
  );
  const woundForDamage = terrainShield
    ? terrainShield.reducedWound
    : Math.max(0, Number(attack.woundTotal || 0));
  const lifeBefore = Math.max(0, Number(defender.system.lifePoints?.value || 0));

  await defender.update({
    "system.damageCalc.source": "wound",

    "system.damageCalc.woundRoll":
      woundForDamage,

    "system.damageCalc.category":
      category,

    "system.damageCalc.defense":
      defense,

    "system.damageCalc.incomingEC":
      Math.max(
        0,
        Number(attack.energyCharges || 0)
      ),

    "system.damageCalc.guardPaidViaCard":
      defense === "guard",

    "system.damageCalc.isRanged":
      String(attack.foundation || "")
        .toLowerCase() !== "physical"
  });

  if (
    typeof sheet._onApplyDamage !== "function"
  ) {
    throw new Error(
      "_onApplyDamage não encontrada."
    );
  }

  await sheet._onApplyDamage({
    preventDefault() {},
    stopPropagation() {}
  });

  // v1.8.0 — Throw / Collision. O DBU 0.9.2 adiciona ao Damage do
  // Throw a redução típica de LP de uma Collision com a Hardness do objeto.
  // Essa parcela acontece DEPOIS do cálculo normal de Wound/Soak e respeita
  // a aptidão nativa collisionDamageMultiplier (ex.: Android / Custom Species).
  const rawFlatDamage = Math.max(0, Math.trunc(Number(attack.flatDamageBonus || 0)));
  let appliedFlatDamage = 0;
  if (rawFlatDamage > 0) {
    const multRaw = Number(defender.system?.aptitudes?.collisionDamageMultiplier);
    const multiplier = Number.isFinite(multRaw) ? Math.max(0, multRaw) : 1;
    appliedFlatDamage = Math.max(0, Math.floor(rawFlatDamage * multiplier));
    if (appliedFlatDamage > 0) {
      const currentLife = Math.max(0, Number(defender.system.lifePoints?.value || 0));
      const afterCollision = Math.max(0, currentLife - appliedFlatDamage);
      const actualCollision = Math.max(0, currentLife - afterCollision);
      appliedFlatDamage = actualCollision;
      await defender.update({ "system.lifePoints.value": afterCollision });
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: defender }),
        content: `<div class="dbu-attack-roll"><div class="dbu-card-body"><div class="dbu-defend-guide"><b>${String(attack.flatDamageLabel || "Collision")}</b>: ${defender.name} perde <b>${actualCollision} LP</b>${multiplier !== 1 ? ` (multiplicador de Collision ×${multiplier})` : ""}.</div></div></div>`
      });
    }
  }

  // O Terrain Shield precisa avaliar somente o Damage causado pelo Attacking
  // Maneuver/Collision. A perda posterior de LP recuperados pelo Combat Recovery
  // é uma consequência do Exploit e não deve destruir/desgastar a Feature.
  if (terrainShield) {
    const lifeAfterAttack = Math.max(0, Number(defender.system.lifePoints?.value || 0));
    const damageTaken = Math.max(0, lifeBefore - lifeAfterAttack);
    await resolveTerrainShield(defender, terrainShield, damageTaken);
  }

  // v1.8.5 TEST — Exploit provocado por Combat Recovery. Pela DBU 0.9.2,
  // se o personagem for atingido pelo Attacking Maneuver usado através desse
  // Exploit, perde os LP que recuperou com Combat Recovery neste Round.
  if (
    String(attack.attackMode || "") === "exploit"
    && String(attack.exploitRecoveryActorId || "") === String(defender.id)
  ) {
    const standardState = defender.getFlag?.(MODULE_ID, "standardManeuverState") || {};
    const recovery = standardState?.combatRecovery || null;
    const recoveredLp = Math.max(0, Number(recovery?.recoveredLp || 0));
    if (recovery?.active && recoveredLp > 0 && !recovery?.exploitLpLost) {
      const beforeLoss = Math.max(0, Number(defender.system.lifePoints?.value || 0));
      const afterLoss = Math.max(0, beforeLoss - recoveredLp);
      const actualLoss = Math.max(0, beforeLoss - afterLoss);
      await defender.update({ "system.lifePoints.value": afterLoss });
      await defender.setFlag(MODULE_ID, "standardManeuverState.combatRecovery", {
        ...recovery,
        recoveredLp: 0,
        exploitLpLost: true,
        exploitLpLostAmount: actualLoss,
        exploitHitAt: Date.now(),
        exploitAttackMessageId: attack.messageId || null
      });
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: defender }),
        content: `<div class="dbu-attack-roll"><div class="dbu-card-body"><div class="dbu-defend-guide"><b>Combat Recovery — Exploit:</b> ${dbuEsc(defender.name)} foi atingido pelo Basic Attack do Exploit e perde <b>${actualLoss} LP</b> recuperados pelo Combat Recovery deste Round.</div></div></div>`
      });
    }
  }
}

// ============================================================
// RESULTADO DA DEFESA + GIF PERSONALIZADO
// ============================================================

async function dbuDefenseResult(
  defender,
  defenseType,
  name,
  total,
  targetLabel,
  target,
  success,
  extra = ""
) {
  const defenseGif = dbuGetDefenseGif(
    defender,
    defenseType
  );

  const defenseGifHTML = dbuDefenseGifHTML(
    defenseGif,
    name
  );

  console.log(
    "DBU | Defense GIF",
    {
      actor: defender.name,
      defenseType,
      gif: defenseGif || "Nenhum"
    }
  );

  await dbuRunDefenseVisual(defender, defenseType, {
    name, total, targetLabel, target, success, extra
  });

  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({
      actor: defender
    }),

    content: `
      <div class="dbu-attack-roll dbu-defend-card">
        <h3 class="dbu-attack-title">
          <span class="dbu-card-title-text">
            ${dbuEsc(defender.name)} — ${dbuEsc(name)}
          </span>
        </h3>

        <div class="dbu-card-body">
          ${defenseGifHTML}

          ${
            total !== null
              ? `
                <div class="dbu-roll-row">
                  <span class="dbu-roll-label">
                    ${dbuEsc(name)}
                  </span>

                  <span class="dbu-roll-main">
                    vs ${dbuEsc(targetLabel)}
                  </span>

                  <span class="dbu-roll-total">
                    ${total} / ${target}
                  </span>
                </div>
              `
              : ""
          }

          ${
            extra
              ? `
                <div class="dbu-attack-meta">
                  <span class="dbu-meta-chip">
                    ${dbuEsc(extra)}
                  </span>
                </div>
              `
              : ""
          }

          <div class="dbu-attack-buffs">
            <strong>
              ${
                success
                  ? "✅ DEFESA BEM-SUCEDIDA"
                  : name === "Guard"
                    ? "🛡 GUARD"
                    : name === "Direct Hit"
                      ? "🎯 DIRECT HIT"
                      : "❌ DEFESA FALHOU"
              }
            </strong>
          </div>
        </div>
      </div>
    `
  });
}

// ============================================================
// RESOLVER DEFESA
// ============================================================

async function dbuResolveDefense(
  defender,
  attack,
  defenseType,
  context = {}
) {
  const deferReveal = !!context?.deferReveal;

  const strike = Number(
    attack.strikeTotal || 0
  );

  const wound = Number(
    attack.woundTotal || 0
  );

  // DUEL CLASH — v6.5
  if (defenseType === "duelClash") {
    if (!context.message) {
      throw new Error(
        "ChatMessage do ataque é necessária para iniciar o Duel Clash."
      );
    }

    return dbuInitiateDuelClash(
      defender,
      attack,
      context.message
    );
  }

  // DODGE
  if (defenseType === "dodge") {
    const roll = await dbuRollDodge(defender, { silent: deferReveal });
    const success = roll.total >= strike;

    if (!deferReveal) {
      await dbuDefenseResult(
        defender,
        "dodge",
        "Dodge",
        roll.total,
        "Strike",
        strike,
        success
      );

      if (!success) {
        await dbuApplyDamage(defender, attack, "none");
      }
    }

    return {
      status: success ? "defended" : "hit",
      text: success
        ? `✅ Dodge — ${roll.total} vs ${strike}`
        : `❌ Dodge — ${roll.total} vs ${strike}`,
      hiddenOutcome: deferReveal ? {
        defenseType: "dodge", name: "Dodge", total: roll.total,
        targetLabel: "Strike", target: strike, success, extra: "",
        damageDefense: success ? null : "none"
      } : null
    };
  }

  // PARRY
  if (defenseType === "parry") {
    const roll = await dbuRollDefend(
      defender,
      "parry",
      attack,
      0,
      { silent: deferReveal }
    );

    const success = roll.total >= strike;

    if (!deferReveal) {
      await dbuDefenseResult(
        defender,
        "parry",
        "Parry",
        roll.total,
        "Strike",
        strike,
        success
      );

      if (!success) {
        await dbuApplyDamage(defender, attack, "none");
      }
    }

    return {
      status: success ? "defended" : "hit",
      text: success
        ? `✅ Parry — ${roll.total} vs ${strike}`
        : `❌ Parry — ${roll.total} vs ${strike}`,
      hiddenOutcome: deferReveal ? {
        defenseType: "parry", name: "Parry", total: roll.total,
        targetLabel: "Strike", target: strike, success, extra: "",
        damageDefense: success ? null : "none"
      } : null
    };
  }

  // DIRECT HIT
  if (defenseType === "directHit") {
    await dbuRecordDefend(
      defender,
      "directHit",
      {
        incomingEC: attack.energyCharges
      }
    );

    if (!deferReveal) {
      await dbuDefenseResult(
        defender,
        "directHit",
        "Direct Hit",
        null,
        "Wound",
        wound,
        false,
        `Wound ${wound}`
      );

      await dbuApplyDamage(defender, attack, "directHit");
    }

    return {
      status: "hit",
      text: `🎯 Direct Hit — Wound ${wound}`,
      hiddenOutcome: deferReveal ? {
        defenseType: "directHit", name: "Direct Hit", total: null,
        targetLabel: "Wound", target: wound, success: false,
        extra: `Wound ${wound}`, damageDefense: "directHit"
      } : null
    };
  }

  // POWER FLARE
  if (defenseType === "powerFlare") {
    const sheet = await dbuPrepareSheet(defender);

    const fallbackMaxWager = Math.floor(
      Number(
        defender.system.status?.maxCapacity || 0
      ) / 5
    );

    const maxWager = Number(
      sheet._trackerDefend?.maxFlareWager
      ?? fallbackMaxWager
      ?? 0
    );

    const wager = await Dialog.wait({
      title: `${defender.name} — Power Flare`,

      content: `
        <div>
          <p>
            Wound recebido: <b>${deferReveal ? "🔒 oculto" : wound}</b>
          </p>

          <p>
            Wager máximo: <b>${maxWager}</b>
          </p>

          <input
            id="dbu-flare-wager"
            type="number"
            min="0"
            max="${maxWager}"
            value="0"
            step="1"
            style="width:100%;"
          >
        </div>
      `,

      buttons: {
        roll: {
          label: "Power Flare",
          callback: html =>
            Math.max(
              0,
              Math.min(
                maxWager,
                Number(
                  html
                    .find("#dbu-flare-wager")
                    .val()
                ) || 0
              )
            )
        },

        cancel: {
          label: "Cancelar",
          callback: () => null
        }
      },

      default: "roll",
      close: () => null
    });

    if (wager === null) {
      return {
        cancelled: true
      };
    }

    const tier = Number(
      defender.system.tier || 1
    );

    const cost = 2 * tier + wager;

    const payment = await dbuPayKiAndCapacity(
      defender,
      cost,
      "Power Flare"
    );

    if (!payment.ok) {
      return {
        cancelled: true
      };
    }

    const roll = await dbuRollDefend(
      defender,
      "powerFlare",
      attack,
      wager,
      { silent: deferReveal }
    );

    const success = roll.total >= wound;

    if (!deferReveal) {
      await dbuDefenseResult(
        defender,
        "powerFlare",
        "Power Flare",
        roll.total,
        "Wound",
        wound,
        success,
        `Cost ${cost} KP / Capacity`
      );

      if (!success) {
        await dbuApplyDamage(defender, attack, "none");
      }
    }

    return {
      status: success ? "defended" : "hit",
      text: success
        ? `✅ Power Flare — ${roll.total} vs ${wound}`
        : `❌ Power Flare — ${roll.total} vs ${wound}`,
      hiddenOutcome: deferReveal ? {
        defenseType: "powerFlare", name: "Power Flare", total: roll.total,
        targetLabel: "Wound", target: wound, success,
        extra: `Cost ${cost} KP / Capacity`,
        damageDefense: success ? null : "none"
      } : null
    };
  }

  // CROSS COUNTER
  if (defenseType === "crossCounter") {
    const tier = Number(
      defender.system.tier || 1
    );

    const cost = 2 * tier;

    const payment = await dbuPayKiAndCapacity(
      defender,
      cost,
      "Cross Counter"
    );

    if (!payment.ok) {
      return {
        cancelled: true
      };
    }

    await dbuRecordDefend(
      defender,
      "crossCounter",
      {
        incomingEC: attack.energyCharges
      }
    );

    const defenseValue = Number(
      defender.system.aptitudes?.defenseValue || 0
    );

    const halfDefense = Math.floor(
      defenseValue / 2
    );

    const success = strike < halfDefense;

    if (!deferReveal) {
      await dbuDefenseResult(
        defender,
        "crossCounter",
        "Cross Counter",
        halfDefense,
        "Strike",
        strike,
        success,
        `Cost ${cost} KP / Capacity`
      );

      if (!success) {
        await dbuApplyDamage(defender, attack, "none");
      }
    }

    return {
      status: success ? "defended" : "hit",
      text: success
        ? `✅ Cross Counter — ${halfDefense} vs ${strike}`
        : `❌ Cross Counter — ${halfDefense} vs ${strike}`,
      hiddenOutcome: deferReveal ? {
        defenseType: "crossCounter", name: "Cross Counter", total: halfDefense,
        targetLabel: "Strike", target: strike, success,
        extra: `Cost ${cost} KP / Capacity`,
        damageDefense: success ? null : "none"
      } : null
    };
  }

  // GUARD
  if (defenseType === "guard") {
    await dbuPrepareSheet(defender);

    const tier = Number(
      defender.system.tier || 1
    );

    const ec = Math.min(
      4,
      Math.max(
        0,
        Number(attack.energyCharges || 0)
      )
    );

    let cost = (8 + ec) * tier;

    if (
      defender._isConditionActive?.(
        defender.system,
        "guardDown"
      )
    ) {
      cost = Math.ceil(cost * 1.5);
    }

    const reduction = Number(
      defender.system.aptitudes
        ?.guardKPReduction || 0
    );

    cost = Math.max(
      0,
      cost - reduction
    );

    const payment = await dbuPayKiAndCapacity(
      defender,
      cost,
      "Guard"
    );

    if (!payment.ok) {
      return {
        cancelled: true
      };
    }

    await dbuRecordDefend(
      defender,
      "guard",
      {
        incomingEC: attack.energyCharges
      }
    );

    if (!deferReveal) {
      await dbuDefenseResult(
        defender,
        "guard",
        "Guard",
        null,
        "Wound",
        wound,
        false,
        `Cost ${cost} KP / Capacity · EC ${ec}`
      );

      await dbuApplyDamage(defender, attack, "guard");
    }

    return {
      status: "guard",
      text: `🛡 Guard — Wound ${wound} · Cost ${cost}`,
      hiddenOutcome: deferReveal ? {
        defenseType: "guard", name: "Guard", total: null,
        targetLabel: "Wound", target: wound, success: false,
        extra: `Cost ${cost} KP / Capacity · EC ${ec}`,
        damageDefense: "guard"
      } : null
    };
  }

  throw new Error(
    `Defesa desconhecida: ${defenseType}`
  );
}

// ============================================================
// ESTADO DA DEFESA NO ACTOR
// ============================================================

function dbuGetDefenseStates(defender) {
  return (
    defender.getFlag(
      "world",
      "dbuDefenseStates"
    )
    || {}
  );
}

function dbuGetDefenseState(
  defender,
  messageId
) {
  return (
    dbuGetDefenseStates(defender)[messageId]
    || null
  );
}

async function dbuSetDefenseState(
  defender,
  messageId,
  state
) {
  const states = foundry.utils.deepClone(
    dbuGetDefenseStates(defender)
  );

  states[messageId] = state;

  await defender.setFlag(
    "world",
    "dbuDefenseStates",
    states
  );
}

async function dbuClearDefensePending(
  defender,
  messageId
) {
  await dbuSetDefenseState(
    defender,
    messageId,
    {
      resolved: false,
      pending: false
    }
  );
}

// ============================================================
// UNITED ATTACK v6.6 — ATAQUE NORMAL
// ============================================================

function dbuMessageIdFromElement(element) {
  return element?.closest?.("[data-message-id]")?.dataset?.messageId || null;
}

function dbuFindCustomAttackMessage(message) {
  if (!message) return null;

  if (message.getFlag("world", "dbuAttackData")) {
    return message;
  }

  return game.messages.contents
    .slice()
    .reverse()
    .find(entry => {
      const attack = entry.getFlag("world", "dbuAttackData");
      return attack?.originalAttackMessageId === message.id;
    }) || null;
}

function dbuUnitedAttackStorageId(message, attack) {
  return String(
    attack?.originalAttackMessageId
    || message?.id
    || ""
  );
}

function dbuGetUnitedAttackContributions(message, attack = null) {
  attack ||= message?.getFlag("world", "dbuAttackData") || null;
  if (!message || !attack) return [];

  const storageId = dbuUnitedAttackStorageId(message, attack);
  if (!storageId) return [];

  return game.actors
    .map(actor => ({
      actor,
      contribution: actor.getFlag(
        DBU_SYSTEM_ID,
        `unitedAttacks.${storageId}`
      )
    }))
    .filter(entry => !!entry.contribution)
    .map(entry => ({
      actorId: entry.actor.id,
      actorName: entry.actor.name,
      attr: String(entry.contribution.attr || ""),
      bonus: Math.max(0, Number(entry.contribution.bonus || 0)),
      wager: Math.max(0, Number(entry.contribution.wager || 0)),
      cost: Math.max(0, Number(entry.contribution.cost || 0)),
      spentAction: entry.contribution.spentAction !== false,
      joinedAt: Number(entry.contribution.joinedAt || 0)
    }));
}

function dbuActorInActiveCombat(actor, combat = game.combat) {
  if (!actor || !combat) return false;
  const started = combat.started === true || (combat.round != null && Number(combat.round) > 0);
  if (!started) return false;
  return Array.from(combat.combatants?.contents || combat.combatants || []).some(entry => {
    if (entry?.actor?.id === actor.id) return true;
    return (entry?.token?.actor?.id || entry?.token?.actorId || null) === actor.id;
  });
}

function dbuUnitedAttackUsedThisRound(actor) {
  // v1.8.1: [1/Round] só bloqueia quem participa de um Encounter ativo.
  if (!dbuActorInActiveCombat(actor)) return false;
  const rounds = actor.system.combatTabState?.rounds || [];
  const round = rounds[rounds.length - 1];

  return !!(round?.actions || []).some(
    action => action?.dbuUnitedAttack === true && !action?.dbuOutsideCombat
  );
}

async function dbuCommitUnitedAttack(
  actor,
  message,
  attack,
  {
    attr,
    bonus,
    wager,
    cost,
    spentAction
  }
) {
  const total = Math.max(0, Number(cost || 0))
    + Math.max(0, Number(wager || 0));

  const currentKi = Number(actor.system.kiPool?.value || 0);
  const capacity = dbuGetCapacity(actor);

  if (currentKi < total) {
    return {
      ok: false,
      reason: "ki",
      text: `${actor.name}: Ki insuficiente. Necessário ${total} KP.`
    };
  }

  if (capacity.max > 0 && capacity.left < total) {
    return {
      ok: false,
      reason: "capacity",
      text: `${actor.name}: Capacity insuficiente. Restante ${capacity.left}, necessário ${total}.`
    };
  }

  const previousCTS = foundry.utils.deepClone(
    actor.system.combatTabState || {}
  );

  const cts = foundry.utils.deepClone(previousCTS);
  const round = dbuGetCurrentRound(actor, cts);

  round.actions.push({
    type: spentAction ? "standard" : "instant",
    source: "",
    kiCost: total,
    dkpCost: 0,
    kiWager: Math.max(0, Number(wager || 0)),
    description:
      `United Attack → ${attack.attackerName || "Ally"} — ${attack.attackName || "Attack"}`,
    dbuUnitedAttack: true,
    dbuOutsideCombat: !dbuActorInActiveCombat(actor) || undefined,
    dbuUnitedAttackMessageId: message.id,
    dbuUnitedAttackOriginalMessageId: attack.originalAttackMessageId || null,
    dbuUnitedAttackAttackerId: attack.attackerId,
    dbuUnitedAttackBonus: Math.max(0, Number(bonus || 0)),
    dbuUnitedAttackAttr: String(attr || ""),
    dbuUnitedAttackCost: Math.max(0, Number(cost || 0)),
    dbuUnitedAttackWager: Math.max(0, Number(wager || 0)),
    dbuUnitedAttackSpentAction: !!spentAction
  });

  try {
    await actor.update({
      "system.kiPool.value": currentKi - total,
      "system.status.capacitySpent": capacity.spent + total,
      "system.combatTabState": cts
    });

    const storageId = dbuUnitedAttackStorageId(message, attack);

    await actor.setFlag(
      DBU_SYSTEM_ID,
      `unitedAttacks.${storageId}`,
      {
        attr: String(attr || ""),
        bonus: Math.max(0, Number(bonus || 0)),
        wager: Math.max(0, Number(wager || 0)),
        cost: Math.max(0, Number(cost || 0)),
        spentAction: !!spentAction,
        customMessageId: message.id,
        originalMessageId: attack.originalAttackMessageId || null,
        attackerId: attack.attackerId,
        joinedAt: Date.now()
      }
    );

    const whisperIds = game.users
      .filter(user =>
        user.isGM
        || actor.testUserPermission(user, "OWNER")
      )
      .map(user => user.id);

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      whisper: whisperIds,
      content: `
        <div class="dbu-ki-deduct">
          <i class="fas fa-hands-helping"></i>
          <b>${dbuEsc(actor.name)}</b> — United Attack<br>
          Additional Power: <b>+${Math.max(0, Number(bonus || 0))}</b> (${dbuEsc(attr)})<br>
          Wager: <b>+${Math.max(0, Number(wager || 0))}</b><br>
          Cost + Wager: <b>-${total} KP / Capacity</b><br>
          Ki: <b>${currentKi} → ${currentKi - total}</b><br>
          Capacity Spent: <b>${capacity.spent} → ${capacity.spent + total}</b>
        </div>
      `
    });

    return { ok: true, total };
  } catch (error) {
    console.error("DBU | United Attack commit:", error);

    try {
      await actor.update({
        "system.kiPool.value": currentKi,
        "system.status.capacitySpent": capacity.spent,
        "system.combatTabState": previousCTS
      });
    } catch {}

    return {
      ok: false,
      reason: "error",
      text: error.message || "Erro registrando United Attack."
    };
  }
}

async function dbuRequestUnitedAttackRefresh(
  message,
  supporter = null
) {
  const payload = {
    type: "dbuRefreshUnitedAttack",
    messageId: message.id,
    supporterId: supporter?.id || null,
    userId: game.user.id
  };

  if (game.user.isGM) {
    await dbuGMRefreshUnitedAttackCard(payload);
    return;
  }

  game.socket.emit(DBU_SOCKET, payload);

  // Espera brevemente o GM atualizar a mensagem para que uma defesa clicada
  // logo em seguida já use o novo Wound.
  if (supporter) {
    for (let attempt = 0; attempt < 40; attempt++) {
      await dbuSleep(50);
      const current = game.messages.get(message.id);
      const contributions = current?.getFlag(
        "world",
        "dbuUnitedAttackContributions"
      ) || [];

      if (contributions.some(entry => entry.actorId === supporter.id)) {
        break;
      }
    }
  }
}

async function dbuRunUnitedAttackJoin(message) {
  const attack = message?.getFlag("world", "dbuAttackData");
  if (!attack) {
    return ui.notifications.error(
      "Dados do ataque não encontrados para United Attack."
    );
  }

  if (
    message.getFlag("world", "dbuUnitedAttackLocked")
    || attack.unitedAttackLocked
  ) {
    return ui.notifications.warn(
      "United Attack encerrado: uma defesa deste ataque já começou."
    );
  }

  const contributions = dbuGetUnitedAttackContributions(
    message,
    attack
  );

  const excluded = new Set([
    attack.attackerId,
    ...contributions.map(entry => entry.actorId)
  ]);

  const owned = game.actors.filter(actor =>
    actor.type === "character"
    && (game.user.isGM || actor.isOwner)
    && !excluded.has(actor.id)
  );

  if (!owned.length) {
    return ui.notifications.warn(
      "Você não possui nenhum personagem elegível para entrar no United Attack."
    );
  }

  let supporter = owned.length === 1 ? owned[0] : null;

  if (!supporter) {
    const choice = await Dialog.wait({
      title: "United Attack — escolha quem ajuda",
      content: `
        <div class="form-group">
          <label><b>Aliado</b></label>
          <select id="dbu-ua-actor" style="width:100%;">
            ${owned.map(actor =>
              `<option value="${actor.id}">${dbuEsc(actor.name)}</option>`
            ).join("")}
          </select>
        </div>
      `,
      buttons: {
        ok: {
          label: "Escolher",
          callback: html => html.find("#dbu-ua-actor").val()
        },
        cancel: {
          label: "Cancelar",
          callback: () => null
        }
      },
      default: "ok",
      close: () => null
    });

    if (!choice) return;
    supporter = game.actors.get(choice);
  }

  if (!supporter) return;

  if (dbuUnitedAttackUsedThisRound(supporter)) {
    return ui.notifications.warn(
      `${supporter.name} já usou United Attack neste Round.`
    );
  }

  const helper = await dbuGetDuelHelper();
  const power = helper.unitedAttackPowerBonus(
    supporter,
    attack.foundation || ""
  );

  const cap = helper.unitedAttackWagerCap(supporter);
  const hasTeamwork = (supporter.system.talents || []).includes("teamwork");
  const profileBaseCost = Number(
    CONFIG.DBU?.profileData?.[attack.profile]?.kpCost || 0
  );
  const profileCost = Math.max(
    0,
    profileBaseCost * Number(supporter.system.tier || 1)
  );

  const choice = await Dialog.wait({
    title: `United Attack — ${supporter.name}`,
    content: `
      <form class="dbu-united-attack-dialog">
        <p>
          Ajudando:
          <b>${dbuEsc(attack.attackerName || "Ally")} — ${dbuEsc(attack.attackName || "Attack")}</b>
        </p>

        <div class="dbu-attack-meta">
          <span class="dbu-meta-chip">
            Additional Power +${power.bonus} (½ ${dbuEsc(power.attr)} ${power.mod})
          </span>
          <span class="dbu-meta-chip">
            Wager máx. ${cap}${hasTeamwork ? " · Teamwork ×2" : ""}
          </span>
        </div>

        <div class="form-group">
          <label><b>Ki Wager</b></label>
          <input id="dbu-ua-wager" type="number" value="0" min="0" max="${cap}" step="1" style="width:100%;">
        </div>

        <div class="form-group">
          <label><b>KP Cost — mesmo Profile${attack.profile ? ` (${dbuEsc(attack.profile)})` : ""}</b></label>
          <input id="dbu-ua-cost" type="number" value="${profileCost}" min="0" step="1" style="width:100%;">
        </div>

        <label style="display:flex;gap:6px;align-items:center;margin-top:8px;">
          <input id="dbu-ua-free-action" type="checkbox">
          Efeito especial: não gasta 1 Action
        </label>

        <p class="notes">
          Regra normal: United Attack [1/Round], aliado adjacente, 1 Action.
          Cost + Wager gastam Ki e Capacity nesta automação.
          Signature Technique pode aplicar até 1(bT) ranks de Advantages manualmente.
        </p>
      </form>
    `,
    buttons: {
      join: {
        icon: '<i class="fas fa-hands-helping"></i>',
        label: "Entrar no United Attack",
        callback: html => ({
          wager: Math.max(
            0,
            Math.min(
              cap,
              Number(html.find("#dbu-ua-wager").val()) || 0
            )
          ),
          cost: Math.max(
            0,
            Number(html.find("#dbu-ua-cost").val()) || 0
          ),
          spentAction: !html.find("#dbu-ua-free-action").prop("checked")
        })
      },
      cancel: {
        label: "Cancelar",
        callback: () => null
      }
    },
    default: "join",
    close: () => null
  });

  if (!choice) return;

  const lockKey = `${message.id}:${supporter.id}`;
  if (globalThis.DBU_UNITED_ATTACK_LOCKS.has(lockKey)) {
    return ui.notifications.warn(
      `${supporter.name}: United Attack já está sendo processado.`
    );
  }

  globalThis.DBU_UNITED_ATTACK_LOCKS.add(lockKey);

  try {
    // Reconfere o lock depois do diálogo.
    const latest = game.messages.get(message.id);
    if (
      latest?.getFlag("world", "dbuUnitedAttackLocked")
      || latest?.getFlag("world", "dbuAttackData")?.unitedAttackLocked
    ) {
      return ui.notifications.warn(
        "United Attack encerrou enquanto o diálogo estava aberto."
      );
    }

    const commit = await dbuCommitUnitedAttack(
      supporter,
      message,
      attack,
      {
        attr: power.attr,
        bonus: power.bonus,
        wager: choice.wager,
        cost: choice.cost,
        spentAction: choice.spentAction
      }
    );

    if (!commit.ok) {
      return ui.notifications.warn(commit.text);
    }

    await dbuRequestUnitedAttackRefresh(
      message,
      supporter
    );

    ui.notifications.info(
      `${supporter.name} entrou no United Attack: +${power.bonus + choice.wager} Wound.`
    );
  } finally {
    globalThis.DBU_UNITED_ATTACK_LOCKS.delete(lockKey);
  }
}

// ============================================================
// UNITED ATTACK — HANDLER CUSTOM + CARTA NATIVA
// ============================================================

const dbuUnitedAttackClickHandler = async event => {
  const customButton = event.target.closest?.(
    "[data-dbu-united-attack-v1]"
  );

  const nativeButton = event.target.closest?.(
    ".dbu-united-attack-join"
  );

  if (!customButton && !nativeButton) return;

  const messageId = dbuMessageIdFromElement(
    customButton || nativeButton
  );

  const clickedMessage = messageId
    ? game.messages.get(messageId)
    : null;

  if (!clickedMessage) return;

  const customMessage = dbuFindCustomAttackMessage(
    clickedMessage
  );

  // Se for uma carta nativa sem correspondente do nosso Ataque v11.5,
  // deixa o comportamento original do DBU intacto.
  if (!customMessage) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  try {
    await dbuRunUnitedAttackJoin(customMessage);
  } catch (error) {
    console.error("DBU | United Attack:", error);
    ui.notifications.error(
      error.message || "Erro no United Attack."
    );
  }
};

document.addEventListener(
  "click",
  dbuUnitedAttackClickHandler,
  true
);

globalThis.DBU_BOOTSTRAP.unitedAttackHandler =
  dbuUnitedAttackClickHandler;

// ============================================================
// UNITED DUEL — CO-TARGET DE ATAQUE MULTI-TARGET
// ============================================================

async function dbuAnnounceDuelOnAttackCard(
  message,
  primaryDefender,
  duelId,
  sourceName
) {
  if (!message) return;

  const payload = {
    type: "dbuSetActiveDuel",
    messageId: message.id,
    primaryDefenderId: primaryDefender.id,
    duelId,
    sourceName: sourceName || "Duel Clash",
    userId: game.user.id
  };

  if (game.user.isGM) {
    await dbuGMSetActiveDuelOnAttack(payload);
  } else {
    game.socket.emit(DBU_SOCKET, payload);

    // Evita corrida entre a atualização "Duel ativo" e a atualização da
    // linha do defensor principal logo depois.
    for (let attempt = 0; attempt < 40; attempt++) {
      await dbuSleep(50);
      const current = game.messages.get(message.id);
      const active = current?.getFlag("world", "dbuActiveDuel");
      if (active?.duelId === duelId) break;
    }
  }
}

const dbuUnitedDuelClickHandler = async event => {
  const button = event.target.closest?.(
    "[data-dbu-united-duel-v1]"
  );

  if (!button) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  const messageId = dbuMessageIdFromElement(button);
  const message = messageId ? game.messages.get(messageId) : null;
  const defenderId = button.dataset.defenderId;
  const duelId = button.dataset.duelId;
  const primaryDefenderId = button.dataset.primaryDefenderId;

  if (!message || !defenderId || !duelId) {
    return ui.notifications.error(
      "Dados do United Duel incompletos."
    );
  }

  const defender = game.actors.get(defenderId);
  if (!defender) return;

  if (!game.user.isGM && !defender.isOwner) {
    return ui.notifications.warn(
      `Você não controla ${defender.name}.`
    );
  }

  const attack = message.getFlag("world", "dbuAttackData");
  if (!(attack?.targetActorIds || []).includes(defender.id)) {
    return ui.notifications.warn(
      `${defender.name} não é co-target deste ataque.`
    );
  }

  if (defender.id === primaryDefenderId) return;

  const defenseState = dbuGetDefenseState(
    defender,
    message.id
  );

  if (defenseState?.resolved || defenseState?.pending) {
    return ui.notifications.warn(
      `${defender.name} já escolheu uma defesa para este ataque.`
    );
  }

  if (defender.getFlag(DBU_SYSTEM_ID, `duels.${duelId}`)) {
    return ui.notifications.warn(
      `${defender.name} já participa deste Duel.`
    );
  }

  const helper = await dbuGetDuelHelper();
  const cap = helper.unitedWagerCap(defender);
  const teamwork = (defender.system.talents || []).includes("teamwork");
  const primary = game.actors.get(primaryDefenderId);

  const confirmed = await Dialog.wait({
    title: `${defender.name} — United Duel`,
    content: `
      <p>
        Entrar como co-target apoiando
        <b>${dbuEsc(primary?.name || "o defensor principal")}</b>?
      </p>
      <p>
        Você concede <b>+1(T)</b> aos Clashes do defensor principal e pode
        distribuir até <b>${cap} KP</b> de wager total no Duel${teamwork ? " (Teamwork ×2)" : ""}.
      </p>
      <p class="notes">
        Depois de entrar no United Duel, você não poderá escolher Dodge/Parry/Guard separadamente para este ataque.
      </p>
    `,
    buttons: {
      join: {
        icon: '<i class="fas fa-hands-helping"></i>',
        label: "Join United Duel",
        callback: () => true
      },
      cancel: {
        label: "Cancelar",
        callback: () => false
      }
    },
    default: "join",
    close: () => false
  });

  if (!confirmed) return;

  await defender.setFlag(
    DBU_SYSTEM_ID,
    `duels.${duelId}`,
    {
      role: "support",
      wagerCap: cap,
      wagers: [0, 0, 0],
      revealed: false,
      dbuUnitedDuelCoTarget: true,
      dbuOriginalAttackMessageId: message.id,
      primaryDefenderId
    }
  );

  await dbuUpdateTargetStatus(
    message,
    defender,
    "unitedDuel",
    `🤝 United Duel → ${primary?.name || "Primary"} · wager cap ${cap}`
  );

  ui.notifications.info(
    `${defender.name} entrou no United Duel.`
  );
};

document.addEventListener(
  "click",
  dbuUnitedDuelClickHandler,
  true
);

globalThis.DBU_BOOTSTRAP.unitedDuelHandler =
  dbuUnitedDuelClickHandler;

// ============================================================
// GM PRINCIPAL
// ============================================================

function dbuIsPrimaryGM() {
  const activeGMs = game.users
    .filter(
      user => user.active && user.isGM
    )
    .sort(
      (a, b) =>
        String(a.id).localeCompare(String(b.id))
    );

  return activeGMs[0]?.id === game.user.id;
}

// ============================================================
// GM ATUALIZA A CARTA
// ============================================================

function dbuCombatTargetIds(attack) {
  return Array.from(new Set((attack?.targetActorIds || []).filter(Boolean)));
}

function dbuCombatProgress(attack, states) {
  const ids = dbuCombatTargetIds(attack);
  const selected = ids.filter(id => states?.[id]?.resolved).length;
  return { ids, selected, total: ids.length, allSelected: ids.length > 0 && selected >= ids.length };
}

function dbuResolvedTargetHTML(defender, text) {
  const safeId = String(defender.id).replace(/[^a-zA-Z0-9_-]/g, "");
  return `
    <div
      class="dbu-area-target"
      data-target-row="${safeId}"
      style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.18);"
    >
      <div class="dbu-attack-meta">
        <span class="dbu-meta-chip">
          <i class="fas fa-crosshairs"></i>
          ${dbuEsc(defender.name)}
        </span>
      </div>
      <div class="dbu-attack-buffs">
        <strong>${dbuEsc(text || "Defesa resolvida")}</strong>
      </div>
    </div>
  `;
}

function dbuDefenseChoiceLabel(type, fallback = "Defesa") {
  const labels = {
    dodge: "Dodge",
    parry: "Parry",
    directHit: "Direct Hit",
    powerFlare: "Power Flare",
    crossCounter: "Cross Counter",
    guard: "Guard",
    duelClash: "Duel Clash",
    unitedDuel: "United Duel"
  };
  return labels[String(type || "")] || String(fallback || "Defesa");
}

function dbuWaitingTargetHTML(defender, progress, defenseName = "Defesa") {
  const safeId = String(defender.id).replace(/[^a-zA-Z0-9_-]/g, "");
  const label = String(defenseName || "Defesa");
  return `
    <div
      class="dbu-area-target"
      data-target-row="${safeId}"
      style="margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.18);"
    >
      <div class="dbu-attack-meta">
        <span class="dbu-meta-chip">
          <i class="fas fa-crosshairs"></i>
          ${dbuEsc(defender.name)}
        </span>
      </div>
      <div class="dbu-attack-buffs dbu-auto-selected-defense">
        <strong><i class="fas fa-check-circle"></i> ${dbuEsc(label)} selecionado — resultado oculto</strong><br>
        <span>Aguardando os demais alvos (${progress.selected}/${progress.total})</span>
      </div>
    </div>
  `;
}

function dbuAttackRevealHTML(attack) {
  const strikeTags = [
    attack?.strikeCritical ? '<span class="dbu-crit">CRIT</span>' : "",
    attack?.strikeBotch ? '<span class="dbu-botch">BOTCH</span>' : ""
  ].filter(Boolean).join(" ");

  const woundTags = [
    attack?.woundCritical ? '<span class="dbu-crit">CRIT</span>' : "",
    attack?.woundBotch ? '<span class="dbu-botch">BOTCH</span>' : ""
  ].filter(Boolean).join(" ");

  return `
    <div class="dbu-roll-row">
      <span class="dbu-roll-label">Strike</span>
      <span class="dbu-roll-main">
        <code class="dbu-roll-formula">${dbuEsc(attack?.strikeDisplayFormula || "")}</code>
        <span class="dbu-roll-sub">
          Nat ${Number(attack?.strikeNatural || 0)} · CT ${Number(attack?.strikeCT || 10)}+ · Botch ${Number(attack?.strikeBotchThreshold || 0) === 0 ? "OFF" : `1-${Number(attack?.strikeBotchThreshold || 1)}`}
        </span>
        ${strikeTags}
      </span>
      <span class="dbu-roll-total">${Number(attack?.strikeTotal || 0)}</span>
    </div>

    <div class="dbu-roll-row">
      <span class="dbu-roll-label">Wound</span>
      <span class="dbu-roll-main">
        <code class="dbu-roll-formula">${dbuEsc(attack?.woundDisplayFormula || "")}</code>
        <span class="dbu-roll-sub">
          Nat ${Number(attack?.woundNatural || 0)} · CT ${Number(attack?.woundCT || 10)}+${Number(attack?.wager || 0) > 0 ? ` · Wager +${Number(attack.wager)}` : ""} · Botch ${Number(attack?.woundBotchThreshold || 0) === 0 ? "OFF" : `1-${Number(attack?.woundBotchThreshold || 1)}`}
        </span>
        ${woundTags}
      </span>
      <span class="dbu-roll-total" data-dbu-wound-total>${Number(attack?.woundTotal || 0)}</span>
    </div>
  `;
}

async function dbuRevealNativeAttackMessage(attack) {
  const originalId = attack?.originalAttackMessageId;
  if (!originalId) return;

  const original = game.messages.get(originalId);
  if (!original) return;

  const reveal = foundry.utils.deepClone(
    original.getFlag(DBU_SYSTEM_ID, "attackReveal") || null
  );
  if (!reveal) return;

  // United Attack altera o Wound depois que a rolagem nativa foi criada.
  // Atualiza o reveal nativo para ele mostrar o MESMO total da carta customizada.
  if (Number.isFinite(Number(attack?.woundTotal))) {
    reveal.woundTotal = Number(attack.woundTotal);

    try {
      const wrapper = document.createElement("div");
      wrapper.innerHTML = String(reveal.revealedHtml || "");
      const rows = wrapper.querySelectorAll(".dbu-roll-row");
      const woundRow = Array.from(rows).find(row =>
        String(row.querySelector(".dbu-roll-label")?.textContent || "")
          .trim()
          .toLowerCase() === "wound"
      );
      const total = woundRow?.querySelector(".dbu-roll-total");
      if (total) total.textContent = String(Number(attack.woundTotal));
      reveal.revealedHtml = wrapper.innerHTML;
    } catch (error) {
      console.warn("DBU | Não consegui sincronizar Wound no reveal nativo:", error);
    }
  }

  reveal.revealed = true;

  const updates = {
    content: reveal.revealedHtml,
    [`flags.${DBU_SYSTEM_ID}.attackReveal`]: reveal,
    "flags.world.dbuAutomationCombatRevealed": true,
    "flags.world.dbuAutomationSecretCombat": false
  };

  await original.update(updates);

  // Feedback de dados somente depois que todos os defensores escolheram.
  try { foundry.audio.AudioHelper.play({ src: CONFIG.sounds.dice }, true); } catch {}
  if (game.dice3d) {
    try {
      const rollDatas = [
        reveal.strikeRollData,
        reveal.woundRollData,
        reveal.strikeCritRollData,
        reveal.woundCritRollData
      ].filter(Boolean);
      for (const data of rollDatas) {
        await game.dice3d.showForRoll(Roll.fromData(data), game.user, true);
      }
    } catch (error) {
      console.warn("DBU | Dice So Nice na revelação conjunta:", error);
    }
  }
}

async function dbuFinalizeHiddenOutcome(defender, attack, outcome, { deferDamage = true } = {}) {
  if (!outcome) return { damagePending: false };

  await dbuDefenseResult(
    defender,
    outcome.defenseType,
    outcome.name,
    outcome.total,
    outcome.targetLabel,
    outcome.target,
    !!outcome.success,
    outcome.extra || ""
  );

  const damagePending = !!outcome.damageDefense;

  // v6.8 / DBU Automation v1.4:
  // o resultado é revelado primeiro. Qualquer dano fica pendente até a janela
  // de Intervene ser encerrada, porque um Deflect bem-sucedido pode cancelar
  // o ataque para TODOS os alvos.
  if (damagePending && !deferDamage) {
    await dbuApplyDamage(defender, attack, outcome.damageDefense);
  }

  return { damagePending };
}

async function dbuGMRevealCombatResults(messageId) {
  if (!game.user.isGM || !dbuIsPrimaryGM()) return;

  globalThis.DBU_COMBAT_REVEAL_LOCKS ||= new Set();
  if (globalThis.DBU_COMBAT_REVEAL_LOCKS.has(messageId)) return;

  let message = game.messages.get(messageId);
  if (!message) return;
  if (message.getFlag("world", "dbuCombatRevealed")) return;
  if (message.getFlag("world", "dbuCombatRevealInProgress")) return;

  const attack = foundry.utils.deepClone(message.getFlag("world", "dbuAttackData") || {});
  let states = foundry.utils.deepClone(message.getFlag("world", "dbuDefenseStates") || {});
  const progress = dbuCombatProgress(attack, states);
  if (!progress.allSelected) return;

  globalThis.DBU_COMBAT_REVEAL_LOCKS.add(messageId);

  try {
    await message.update({ "flags.world.dbuCombatRevealInProgress": true });

    // Resolve mensagens e dano apenas agora, quando todos já escolheram.
    for (const actorId of progress.ids) {
      const state = states[actorId];
      if (!state || state.finalized) continue;

      const defender = game.actors.get(actorId);
      let finalizeInfo = { damagePending: false };
      if (defender && state.hiddenOutcome) {
        try {
          finalizeInfo = await dbuFinalizeHiddenOutcome(
            defender,
            attack,
            state.hiddenOutcome,
            { deferDamage: true }
          );
        } catch (error) {
          console.error(`DBU | Revelação da defesa de ${defender.name}:`, error);
          ui.notifications.error(`DBU: erro finalizando a defesa de ${defender.name}.`);
        }
      }

      const damagePending = !!finalizeInfo?.damagePending;

      states[actorId] = {
        ...state,
        finalized: true,
        finalizedAt: Date.now(),
        damagePending,
        damageResolved: !damagePending,
        intervention: damagePending
          ? { status: "pending", openedAt: Date.now() }
          : null
      };

      // Salva progresso para evitar reaplicar dano se houver erro depois.
      await message.update({ "flags.world.dbuDefenseStates": states });
    }

    message = game.messages.get(messageId) || message;
    const wrapper = document.createElement("div");
    wrapper.innerHTML = String(message.content || "");

    const secretResults = wrapper.querySelector("[data-dbu-secret-attack-results]");
    if (secretResults) secretResults.innerHTML = dbuAttackRevealHTML(attack);

    const waitStatus = wrapper.querySelector("[data-dbu-secret-wait-status]");
    if (waitStatus) {
      waitStatus.innerHTML = "<strong>🔓 Todos os alvos registraram suas defesas — resultados revelados.</strong>";
    }

    for (const actorId of progress.ids) {
      const defender = game.actors.get(actorId);
      const state = states[actorId];
      if (!defender || !state) continue;
      const safeId = String(actorId).replace(/[^a-zA-Z0-9_-]/g, "");
      const row = wrapper.querySelector(`[data-target-row="${safeId}"]`);
      if (row) row.outerHTML = dbuResolvedTargetHTML(defender, state.text || "Defesa resolvida");
    }

    await message.update({
      content: wrapper.innerHTML,
      "flags.world.dbuDefenseStates": states,
      "flags.world.dbuCombatRevealed": true,
      "flags.world.dbuCombatRevealInProgress": false
    });

    await dbuRevealNativeAttackMessage(attack);

    const pendingIntervenes = Object.values(states).filter(st => st?.damagePending && !st?.damageResolved).length;
    ui.notifications.info(
      pendingIntervenes > 0
        ? `${attack.attackerName || "Ataque"}: resultados revelados. ${pendingIntervenes} impacto(s) aguardando Intervene.`
        : `${attack.attackerName || "Ataque"}: todos escolheram suas defesas. Resultados revelados.`
    );
  } catch (error) {
    console.error("DBU | Revelação conjunta:", error);
    try {
      const current = game.messages.get(messageId);
      await current?.update({ "flags.world.dbuCombatRevealInProgress": false });
    } catch {}
  } finally {
    globalThis.DBU_COMBAT_REVEAL_LOCKS.delete(messageId);
  }
}

async function dbuGMUpdateDefenseCard({
  messageId,
  defenderId,
  status,
  text,
  defenseType = "",
  defenseName = "",
  hiddenOutcome = null,
  userId = null
}) {
  if (!game.user.isGM) return;

  const message = game.messages.get(messageId);
  const defender = game.actors.get(defenderId);

  if (!message || !defender) return;

  if (userId) {
    const requester = game.users.get(userId);
    if (!requester) return;

    const allowed = requester.isGM || defender.testUserPermission(requester, "OWNER");
    if (!allowed) {
      console.warn("DBU | Socket recusado: usuário sem OWNER.", { userId, defenderId, messageId });
      return;
    }
  }

  const attack = foundry.utils.deepClone(message.getFlag("world", "dbuAttackData") || {});
  const states = foundry.utils.deepClone(message.getFlag("world", "dbuDefenseStates") || {});

  const hasTarget = Object.prototype.hasOwnProperty.call(states, defenderId)
    || dbuCombatTargetIds(attack).includes(defenderId);

  if (!hasTarget) {
    console.warn("DBU | Defensor não pertence a essa carta.");
    return;
  }

  const selectedDefenseType = String(
    defenseType
    || hiddenOutcome?.defenseType
    || states[defenderId]?.defenseType
    || ""
  );
  const selectedDefenseName = String(
    defenseName
    || hiddenOutcome?.name
    || states[defenderId]?.defenseName
    || dbuDefenseChoiceLabel(selectedDefenseType)
  );

  states[defenderId] = {
    ...(states[defenderId] || {}),
    resolved: true,
    pending: false,
    status,
    text,
    defenseType: selectedDefenseType || states[defenderId]?.defenseType || null,
    defenseName: selectedDefenseName,
    hiddenOutcome: hiddenOutcome ? foundry.utils.deepClone(hiddenOutcome) : null,
    selectedAt: Date.now()
  };

  const progress = dbuCombatProgress(attack, states);
  const wrapper = document.createElement("div");
  wrapper.innerHTML = String(message.content || "");

  const safeId = String(defenderId).replace(/[^a-zA-Z0-9_-]/g, "");
  const row = wrapper.querySelector(`[data-target-row="${safeId}"]`);
  if (row) {
    row.outerHTML = message.getFlag("world", "dbuCombatRevealed")
      ? dbuResolvedTargetHTML(defender, text)
      : dbuWaitingTargetHTML(defender, progress, selectedDefenseName);
  }

  const waitStatus = wrapper.querySelector("[data-dbu-secret-wait-status]");
  if (waitStatus && !message.getFlag("world", "dbuCombatRevealed")) {
    waitStatus.innerHTML = `<span><i class="fas fa-lock"></i> Resultados ocultos</span><strong>${progress.selected}/${progress.total} defesas registradas</strong>`;
  }

  await message.update({
    content: wrapper.innerHTML,
    "flags.world.dbuDefenseStates": states
  });

  console.log(`DBU | Defesa registrada secretamente: ${defender.name} (${progress.selected}/${progress.total})`);

  if (progress.allSelected) {
    await dbuGMRevealCombatResults(messageId);
  }
}

// ============================================================
// GM — UNITED ATTACK / LOCK / ACTIVE DUEL
// ============================================================

function dbuRenderUnitedAttackIntoContent(
  message,
  attack,
  contributions,
  locked
) {
  const wrapper = document.createElement("div");
  wrapper.innerHTML = String(message.content || "");

  const baseWound = Number(
    attack.baseWoundTotal
    ?? (Number(attack.woundTotal || 0) - Number(attack.unitedAttackBonus || 0))
  );

  const totalBonus = contributions.reduce(
    (sum, entry) => sum + Number(entry.bonus || 0) + Number(entry.wager || 0),
    0
  );

  const finalWound = baseWound + totalBonus;
  const secretCombat = !!message.getFlag("world", "dbuCombatSecretMode");
  const combatRevealed = !!message.getFlag("world", "dbuCombatRevealed");
  const hideFinalWound = secretCombat && !combatRevealed;

  const wound = wrapper.querySelector("[data-dbu-wound-total]");
  if (wound) wound.textContent = hideFinalWound ? "?" : String(finalWound);

  const list = wrapper.querySelector("[data-dbu-ua-list]");
  if (list) {
    if (!contributions.length) {
      list.innerHTML = `
        <div class="dbu-duel-support-row">
          <span class="dbu-meta-chip">Nenhum aliado entrou ainda.</span>
        </div>
      `;
    } else {
      list.innerHTML = contributions.map(entry => `
        <div class="dbu-duel-support-row">
          <span class="dbu-duel-support-name">
            <i class="fas fa-hands-helping"></i>
            ${dbuEsc(entry.actorName)}
          </span>
          <span class="dbu-meta-chip">
            +${entry.bonus + entry.wager} Wound
            (½${dbuEsc(entry.attr)} ${entry.bonus}${entry.wager ? ` + wager ${entry.wager}` : ""})
          </span>
        </div>
      `).join("") + `
        <div class="dbu-duel-support-row">
          <span class="dbu-meta-chip dbu-chip-hot">
            ${hideFinalWound
              ? `United Attack total: <b>+${totalBonus}</b> · WOUND FINAL 🔒`
              : `WOUND: <b>${finalWound}</b> (${baseWound} + United ${totalBonus})`}
          </span>
        </div>
      `;
    }
  }

  const status = wrapper.querySelector("[data-dbu-ua-status]");
  if (status) {
    status.textContent = locked
      ? "United Attack encerrado — uma defesa já começou."
      : contributions.length
        ? `United Attack total: +${totalBonus} Wound. Outros aliados ainda podem entrar.`
        : "Antes da primeira defesa: +½ FO/MA + Ki Wager ao Wound.";
  }

  wrapper
    .querySelectorAll("[data-dbu-united-attack-v1]")
    .forEach(button => {
      button.disabled = !!locked;
      if (locked) {
        button.innerHTML = '<i class="fas fa-lock"></i> United Attack encerrado';
      }
    });

  return {
    content: wrapper.innerHTML,
    baseWound,
    totalBonus,
    finalWound
  };
}

async function dbuGMRefreshUnitedAttackCard({
  messageId,
  supporterId = null,
  userId = null
}) {
  if (!game.user.isGM) return;

  const message = game.messages.get(messageId);
  if (!message) return;

  const attack = foundry.utils.deepClone(
    message.getFlag("world", "dbuAttackData") || {}
  );

  if (!attack.attackerId) return;

  if (userId && supporterId) {
    const requester = game.users.get(userId);
    const supporter = game.actors.get(supporterId);

    const allowed = !!requester && !!supporter && (
      requester.isGM
      || supporter.testUserPermission(requester, "OWNER")
    );

    if (!allowed) {
      console.warn("DBU | United Attack socket recusado.", {
        messageId,
        supporterId,
        userId
      });
      return;
    }
  }

  const contributions = dbuGetUnitedAttackContributions(
    message,
    attack
  );

  const locked = !!message.getFlag(
    "world",
    "dbuUnitedAttackLocked"
  );

  const rendered = dbuRenderUnitedAttackIntoContent(
    message,
    attack,
    contributions,
    locked
  );

  attack.baseWoundTotal = rendered.baseWound;
  attack.woundTotal = rendered.finalWound;
  attack.unitedAttackBonus = rendered.totalBonus;
  attack.unitedAttackLocked = locked;
  attack.unitedAttackContributions = foundry.utils.deepClone(
    contributions
  );

  await message.update({
    content: rendered.content,
    "flags.world.dbuAttackData": attack,
    "flags.world.dbuUnitedAttackContributions": contributions
  });

  console.log(
    `DBU | United Attack atualizado: ${attack.attackName} +${rendered.totalBonus} Wound`
  );
}

async function dbuGMSetUnitedAttackLock({
  messageId,
  locked = true,
  defenderId = null,
  userId = null,
  safeUnlock = false
}) {
  if (!game.user.isGM) return;

  const message = game.messages.get(messageId);
  if (!message) return;

  if (userId && defenderId) {
    const requester = game.users.get(userId);
    const defender = game.actors.get(defenderId);
    const allowed = !!requester && !!defender && (
      requester.isGM
      || defender.testUserPermission(requester, "OWNER")
    );
    if (!allowed) return;
  }

  const attack = foundry.utils.deepClone(
    message.getFlag("world", "dbuAttackData") || {}
  );

  if (safeUnlock && !locked) {
    const hasOtherDefense = (attack.targetActorIds || []).some(actorId => {
      const actor = game.actors.get(actorId);
      const state = actor?.getFlag("world", "dbuDefenseStates")?.[messageId];
      return !!(state?.resolved || state?.pending);
    });

    if (hasOtherDefense) return;
  }

  attack.unitedAttackLocked = !!locked;

  const contributions = dbuGetUnitedAttackContributions(
    message,
    attack
  );

  const rendered = dbuRenderUnitedAttackIntoContent(
    message,
    attack,
    contributions,
    !!locked
  );

  attack.baseWoundTotal = rendered.baseWound;
  attack.woundTotal = rendered.finalWound;
  attack.unitedAttackBonus = rendered.totalBonus;
  attack.unitedAttackContributions = contributions;

  await message.update({
    content: rendered.content,
    "flags.world.dbuAttackData": attack,
    "flags.world.dbuUnitedAttackLocked": !!locked,
    "flags.world.dbuUnitedAttackContributions": contributions
  });
}

async function dbuRequestUnitedAttackLock(
  message,
  defender,
  locked = true,
  { safeUnlock = false } = {}
) {
  if (!message) return;

  const payload = {
    type: "dbuSetUnitedAttackLock",
    messageId: message.id,
    defenderId: defender?.id || null,
    locked: !!locked,
    safeUnlock: !!safeUnlock,
    userId: game.user.id
  };

  if (game.user.isGM) {
    await dbuGMSetUnitedAttackLock(payload);
    return;
  }

  game.socket.emit(DBU_SOCKET, payload);

  if (locked) {
    for (let attempt = 0; attempt < 12; attempt++) {
      await dbuSleep(25);
      const current = game.messages.get(message.id);
      if (current?.getFlag("world", "dbuUnitedAttackLocked")) break;
    }
  }
}

async function dbuGMSetActiveDuelOnAttack({
  messageId,
  primaryDefenderId,
  duelId,
  sourceName = "Duel Clash",
  userId = null
}) {
  if (!game.user.isGM) return;

  const message = game.messages.get(messageId);
  const primary = game.actors.get(primaryDefenderId);
  if (!message || !primary) return;

  if (userId) {
    const requester = game.users.get(userId);
    const allowed = !!requester && (
      requester.isGM
      || primary.testUserPermission(requester, "OWNER")
    );
    if (!allowed) return;
  }

  const attack = foundry.utils.deepClone(
    message.getFlag("world", "dbuAttackData") || {}
  );

  const activeDuel = {
    duelId,
    primaryDefenderId,
    primaryDefenderName: primary.name,
    sourceName,
    startedAt: Date.now()
  };

  attack.unitedAttackLocked = true;

  const contributions = dbuGetUnitedAttackContributions(
    message,
    attack
  );

  const rendered = dbuRenderUnitedAttackIntoContent(
    message,
    attack,
    contributions,
    true
  );

  const wrapper = document.createElement("div");
  wrapper.innerHTML = rendered.content;

  for (const row of wrapper.querySelectorAll(".dbu-area-target")) {
    const actions = row.querySelector(".dbu-attack-actions");
    if (!actions) continue;

    const anyDefense = actions.querySelector("[data-defender-id]");
    const defenderId = anyDefense?.dataset?.defenderId;
    if (!defenderId || defenderId === primaryDefenderId) continue;
    if (!(attack.targetActorIds || []).includes(defenderId)) continue;

    actions
      .querySelectorAll('[data-dbu-defense-v5="duelClash"]')
      .forEach(button => button.remove());

    if (!actions.querySelector("[data-dbu-united-duel-v1]")) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "dbu-pay-btn dbu-united-duel-btn";
      button.dataset.dbuUnitedDuelV1 = "1";
      button.dataset.defenderId = defenderId;
      button.dataset.duelId = duelId;
      button.dataset.primaryDefenderId = primaryDefenderId;
      button.innerHTML = '<i class="fas fa-hands-helping"></i> Join United Duel';
      actions.appendChild(button);
    }
  }

  attack.baseWoundTotal = rendered.baseWound;
  attack.woundTotal = rendered.finalWound;
  attack.unitedAttackBonus = rendered.totalBonus;
  attack.unitedAttackContributions = contributions;

  await message.update({
    content: wrapper.innerHTML,
    "flags.world.dbuAttackData": attack,
    "flags.world.dbuUnitedAttackLocked": true,
    "flags.world.dbuUnitedAttackContributions": contributions,
    "flags.world.dbuActiveDuel": activeDuel
  });
}

// ============================================================
// GM — DEVOLVER COUNTER ACTION APÓS DUEL ESCAPE
// ============================================================

async function dbuGMRefundDuelCounter({
  defenderId,
  duelId,
  userId = null
}) {
  if (!game.user.isGM) return;

  const defender = game.actors.get(defenderId);
  if (!defender) return;

  const context = dbuGetDuelContext(defender, duelId);
  if (!context) return;

  if (userId) {
    const requester = game.users.get(userId);
    const attacker = game.actors.get(context.attackerId);

    const allowed = !!requester && (
      requester.isGM
      || attacker?.testUserPermission(requester, "OWNER")
    );

    if (!allowed) {
      console.warn(
        "DBU | Socket recusado: refund de Duel sem permissão.",
        { defenderId, duelId, userId }
      );
      return;
    }
  }

  await dbuRefundDuelCounter(
    defender,
    context
  );
}

// ============================================================
// SOCKET
// ============================================================

const dbuSocketHandler = async data => {
  if (!data) return;
  if (!dbuIsPrimaryGM()) return;

  try {
    if (data.type === "dbuUpdateDefenseCard") {
      await dbuGMUpdateDefenseCard(data);
      return;
    }

    if (data.type === "dbuRefundDuelCounter") {
      await dbuGMRefundDuelCounter(data);
      return;
    }

    if (data.type === "dbuRefreshUnitedAttack") {
      await dbuGMRefreshUnitedAttackCard(data);
      return;
    }

    if (data.type === "dbuSetUnitedAttackLock") {
      await dbuGMSetUnitedAttackLock(data);
      return;
    }

    if (data.type === "dbuSetActiveDuel") {
      await dbuGMSetActiveDuelOnAttack(data);
      return;
    }
  } catch (error) {
    console.error(
      "DBU | Socket:",
      error
    );
  }
};

game.socket.on(
  DBU_SOCKET,
  dbuSocketHandler
);

globalThis.DBU_BOOTSTRAP.socketHandler =
  dbuSocketHandler;

// ============================================================
// v6.7 — BLOQUEAR REVEAL NATIVO ATÉ TODAS AS DEFESAS
// ============================================================

function dbuSecretCombatFromNativeMessage(message) {
  const defenseMessageId = message?.getFlag("world", "dbuAutomationDefenseMessageId");
  if (!defenseMessageId) return null;

  const defenseMessage = game.messages.get(defenseMessageId);
  if (!defenseMessage) return null;

  const attack = defenseMessage.getFlag("world", "dbuAttackData") || {};
  const states = defenseMessage.getFlag("world", "dbuDefenseStates") || {};
  const progress = dbuCombatProgress(attack, states);

  return {
    defenseMessage,
    revealed: !!defenseMessage.getFlag("world", "dbuCombatRevealed"),
    progress
  };
}

const dbuSecretRevealHandler = event => {
  const button = event.target.closest?.("[data-dbu-reveal]");
  if (!button) return;

  const messageElement = button.closest?.("[data-message-id]");
  const messageId = messageElement?.dataset?.messageId;
  const message = messageId ? game.messages.get(messageId) : null;
  if (!message) return;

  const secret = dbuSecretCombatFromNativeMessage(message);
  if (!secret || secret.revealed || secret.progress.allSelected) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  ui.notifications.warn(
    `Ataque oculto: aguardando defesas (${secret.progress.selected}/${secret.progress.total}).`
  );
};

document.addEventListener("click", dbuSecretRevealHandler, true);
globalThis.DBU_BOOTSTRAP.secretRevealHandler = dbuSecretRevealHandler;

const secretRevealHookId = Hooks.on("renderChatMessage", (message, html) => {
  try {
    const secret = dbuSecretCombatFromNativeMessage(message);
    if (!secret || secret.revealed) return;

    const root = html instanceof HTMLElement ? html : (html?.[0] || html);
    const button = root?.querySelector?.("[data-dbu-reveal]");
    if (!button) return;

    if (!secret.progress.allSelected) {
      button.disabled = true;
      button.innerHTML = `<i class="fas fa-lock"></i> Aguardando defesas ${secret.progress.selected}/${secret.progress.total}`;
      button.title = "O resultado será revelado automaticamente quando todos os alvos registrarem suas defesas.";
    }
  } catch (error) {
    console.error("DBU | Secret Reveal render:", error);
  }
});

globalThis.DBU_BOOTSTRAP.secretRevealHookId = secretRevealHookId;

// ============================================================
// FINALIZAR DEFESA
// ============================================================

async function dbuUpdateTargetStatus(
  message,
  defender,
  status,
  text,
  details = null
) {
  const hiddenOutcome = details?.hiddenOutcome
    ? foundry.utils.deepClone(details.hiddenOutcome)
    : null;
  const defenseType = String(
    details?.selectedDefenseType
    || hiddenOutcome?.defenseType
    || ""
  );
  const defenseName = String(
    details?.selectedDefenseName
    || hiddenOutcome?.name
    || dbuDefenseChoiceLabel(defenseType)
  );

  await dbuSetDefenseState(
    defender,
    message.id,
    {
      resolved: true,
      pending: false,
      status,
      text,
      defenseType,
      defenseName,
      hiddenOutcome,
      resolvedBy: game.user.id,
      resolvedAt: Date.now()
    }
  );

  const payload = {
    type: "dbuUpdateDefenseCard",
    messageId: message.id,
    defenderId: defender.id,
    status,
    text,
    defenseType,
    defenseName,
    hiddenOutcome,
    userId: game.user.id
  };

  if (game.user.isGM) {
    await dbuGMUpdateDefenseCard(payload);
  } else {
    game.socket.emit(
      DBU_SOCKET,
      payload
    );
  }
}

// ============================================================
// v6.10 — FALLBACK DE SINCRONIZAÇÃO DA DEFESA VIA ACTOR
// ============================================================
//
// O player é dono do próprio Actor e consegue salvar dbuDefenseStates mesmo
// quando não tem permissão para editar a ChatMessage do atacante. O socket é
// a via principal; este hook no GM observa a flag do Actor e sincroniza a
// carta como fallback, evitando que o combate fique preso aguardando uma
// defesa que já foi escolhida.
// ============================================================

const defenseActorSyncHookId = Hooks.on(
  "updateActor",
  async (actor, changes) => {
    if (!dbuIsPrimaryGM()) return;

    const touched =
      foundry.utils.hasProperty(changes, "flags.world.dbuDefenseStates")
      || Object.keys(changes || {}).some(key =>
        String(key).startsWith("flags.world.dbuDefenseStates")
      );

    if (!touched) return;

    const actorStates = dbuGetDefenseStates(actor);

    for (const [messageId, state] of Object.entries(actorStates || {})) {
      if (!state?.resolved) continue;

      // Se foi o próprio GM que resolveu, a rota direta já atualiza a carta.
      if (state.resolvedBy === game.user.id) continue;

      const message = game.messages.get(messageId);
      if (!message) continue;

      const attack = message.getFlag("world", "dbuAttackData");
      if (!attack || !dbuCombatTargetIds(attack).includes(actor.id)) continue;

      const messageStates = message.getFlag("world", "dbuDefenseStates") || {};
      if (messageStates?.[actor.id]?.resolved) continue;

      try {
        await dbuGMUpdateDefenseCard({
          messageId,
          defenderId: actor.id,
          status: state.status || "selected",
          text: state.text || `${state.defenseName || "Defesa"} selecionada`,
          defenseType: state.defenseType || "",
          defenseName: state.defenseName || "",
          hiddenOutcome: state.hiddenOutcome || null,
          userId: null
        });

        console.log(
          `DBU | Defesa sincronizada via Actor fallback: ${actor.name}`
        );
      } catch (error) {
        console.error(
          "DBU | Falha sincronizando defesa via Actor:",
          error
        );
      }
    }
  }
);

globalThis.DBU_BOOTSTRAP.defenseActorSyncHookId =
  defenseActorSyncHookId;

// ============================================================
// v7.0 — DEFESA PELO PAINEL (MESMO CORE DA CARTA)
// ============================================================

async function dbuDefendFromPanel(messageId, defenderId, defenseType) {
  const message = game.messages.get(String(messageId || ""));
  const defender = game.actors.get(String(defenderId || ""));
  const type = String(defenseType || "");
  if (!message || !defender || !type) {
    return ui.notifications.error("DBU Painel: dados da defesa incompletos.");
  }
  if (!game.user.isGM && !defender.isOwner) {
    return ui.notifications.warn(`Você não controla ${defender.name}.`);
  }

  const attack = message.getFlag("world", "dbuAttackData");
  if (!attack || !dbuCombatTargetIds(attack).includes(defender.id)) {
    return ui.notifications.warn(`${defender.name} não é alvo deste ataque.`);
  }

  await dbuRequestUnitedAttackLock(message, defender, true);
  const lockKey = `${message.id}:${defender.id}`;
  if (globalThis.DBU_DEFENSE_LOCKS.has(lockKey)) {
    return ui.notifications.warn(`${defender.name} já está resolvendo esta defesa.`);
  }
  globalThis.DBU_DEFENSE_LOCKS.add(lockKey);

  let currentState = dbuGetDefenseState(defender, message.id);
  if (currentState?.resolved) {
    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);
    return ui.notifications.warn(`${defender.name} já resolveu esta defesa.`);
  }
  if (currentState?.pending) {
    const age = Date.now() - Number(currentState.lockedAt || 0);
    if (age < DBU_PENDING_TIMEOUT) {
      globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);
      return ui.notifications.warn(`${defender.name} já está resolvendo esta defesa.`);
    }
    await dbuClearDefensePending(defender, message.id);
  }

  const lockToken = `${game.user.id}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  try {
    await dbuSetDefenseState(defender, message.id, {
      resolved:false, pending:true, defenseType:type,
      lockedBy:game.user.id, lockToken, lockedAt:Date.now()
    });
    await dbuSleep(50);
    currentState = dbuGetDefenseState(defender, message.id);
    if (currentState?.lockToken !== lockToken) {
      globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);
      return ui.notifications.warn(`${defender.name} já está sendo defendido por outro usuário.`);
    }

    const result = await dbuResolveDefense(defender, attack, type, { message, deferReveal:true });
    if (result?.cancelled) {
      await dbuClearDefensePending(defender, message.id);
      await dbuRequestUnitedAttackLock(message, defender, false, {safeUnlock:true});
      globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);
      return null;
    }

    const selectedDefenseName = String(result?.hiddenOutcome?.name || dbuDefenseChoiceLabel(type));
    await dbuUpdateTargetStatus(message, defender, result.status, result.text, {
      ...result,
      selectedDefenseType:type,
      selectedDefenseName
    });
    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);
    return result;
  } catch (error) {
    console.error("DBU | Defesa pelo painel:", error);
    try {
      await dbuClearDefensePending(defender, message.id);
      await dbuRequestUnitedAttackLock(message, defender, false, {safeUnlock:true});
    } catch {}
    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);
    ui.notifications.error(error?.message || "Erro resolvendo defesa pelo painel.");
    return null;
  }
}

// ============================================================
// API GLOBAL
// ============================================================

globalThis.DBU = {
  version: DBU_INIT_VERSION,
  getCapacity: dbuGetCapacity,
  canAfford: dbuCheckAffordability,
  payKiAndCapacity: dbuPayKiAndCapacity,
  resolveDefense: dbuResolveDefense,
  defendFromPanel: dbuDefendFromPanel,
  updateTargetStatus: dbuUpdateTargetStatus,
  getDefenseState: dbuGetDefenseState,
  setDefenseState: dbuSetDefenseState,
  getDefenseGif: dbuGetDefenseGif,
  initiateDuelClash: dbuInitiateDuelClash,
  getDuelContext: dbuGetDuelContext,
  setupIncomingDuelAttacker: dbuSetupIncomingDuelAttacker,
  getUnitedAttackContributions: dbuGetUnitedAttackContributions,
  refreshUnitedAttack: dbuRequestUnitedAttackRefresh,
  joinUnitedAttack: dbuRunUnitedAttackJoin,
  rollDodge: dbuRollDodge,
  rollDefend: dbuRollDefend,
  applyDamage: dbuApplyDamage,
  recordDefend: dbuRecordDefend
};

// ============================================================
// BLOQUEIO DE ROLL ATTACK NATIVO — KI + CAPACITY
// ============================================================
//
// O Attack Core do módulo já faz a validação antes de rolar. Este hook cobre
// também quem tentar usar diretamente o botão Roll Attack do Combat Tracker
// da ficha DBU, evitando uma rota alternativa que ignoraria a Capacity.
// ============================================================

function dbuAttachNativeAttackCapacityGuard(app, html) {
  const actor = app?.actor;
  if (!actor) return;

  const root = html instanceof HTMLElement
    ? html
    : html?.[0] || app?.element?.[0] || app?.element || null;

  if (!root?.addEventListener) return;
  if (root.dataset?.dbuAttackCapacityGuard === DBU_INIT_VERSION) return;

  try {
    if (root.dataset) {
      root.dataset.dbuAttackCapacityGuard = DBU_INIT_VERSION;
    }
  } catch {}

  root.addEventListener(
    "click",
    event => {
      const button = event.target.closest?.(
        "[data-action='roll-tracker-attack']"
      );

      if (!button || !root.contains(button)) return;

      const roundNumber = Number(button.dataset.round || 0);
      const actionIndex = Number(button.dataset.actionIndex);

      if (!Number.isInteger(actionIndex) || actionIndex < 0) return;

      const rounds = actor.system.combatTabState?.rounds || [];
      const round = rounds.find(entry =>
        Number(entry?.roundNumber || 0) === roundNumber
      ) || rounds[rounds.length - 1];

      const action = round?.actions?.[actionIndex];
      if (!action || action.type !== "attack") return;

      const kiCost = Math.max(0, Number(action.kiCost || 0));
      const wager = Math.max(0, Number(action.kiWager || 0));
      const total = kiCost + wager;

      const check = dbuCheckAffordability(
        actor,
        total,
        `${action.description || "Ataque"} (Cost + Wager)`,
        true
      );

      if (check.ok) return;

      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      console.warn(
        "DBU | Roll Attack nativo bloqueado por recursos insuficientes",
        {
          actor: actor.name,
          action,
          kiCost,
          wager,
          total,
          check
        }
      );
    },
    true
  );
}

const nativeAttackCapacityHookId = Hooks.on(
  "renderActorSheet",
  dbuAttachNativeAttackCapacityGuard
);

globalThis.DBU_BOOTSTRAP.nativeAttackCapacityHookId =
  nativeAttackCapacityHookId;

// ============================================================
// PAY ORIGINAL DO DBU — KI + CAPACITY
// ============================================================

const dbuNativePayHandler = async event => {
  const button = event.target.closest?.(
    "[data-dbu-pay]"
  );

  if (!button) return;

  const payType = button.dataset.dbuPay;

  if (
    payType !== "combined"
    && payType !== "defend"
    && payType !== "draining"
  ) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  const messageElement = button.closest(
    "[data-message-id]"
  );

  const messageId =
    messageElement?.dataset?.messageId || null;

  const card = button.closest(
    "[data-actor-id]"
  );

  const actorId =
    button.dataset.actorId
    || card?.dataset.actorId;

  const actor = game.actors.get(actorId);

  if (!actor) {
    return ui.notifications.error(
      "DBU: Actor do pagamento não encontrado."
    );
  }

  if (
    !game.user.isGM
    && !actor.isOwner
  ) {
    return ui.notifications.warn(
      "Você não controla esse personagem."
    );
  }

  const payLockKey =
    `${messageId || "no-message"}:${actor.id}:${payType}`;

  if (
    globalThis.DBU_PAY_LOCKS.has(payLockKey)
  ) {
    return ui.notifications.warn(
      `${actor.name}: este pagamento já está sendo processado.`
    );
  }

  globalThis.DBU_PAY_LOCKS.add(payLockKey);

  if (button.disabled) {
    globalThis.DBU_PAY_LOCKS.delete(payLockKey);
    return;
  }

  button.disabled = true;
  button.classList.add("dbu-pay-pending");

  let amount = Number(
    button.dataset.amount
  );

  if (
    !Number.isFinite(amount)
    || amount <= 0
  ) {
    amount =
      Number(button.dataset.kiCost || 0)
      + Number(
        button.dataset.kiWager
        || button.dataset.wager
        || 0
      );
  }

  amount = Math.max(
    0,
    Number(amount) || 0
  );

  const label = payType === "combined"
    ? "Ataque"
    : payType === "draining"
      ? "Draining"
      : "Defend";

  if (amount <= 0) {
    button.classList.remove("dbu-pay-pending");
    button.classList.add("dbu-pay-paid");
    button.innerHTML = `
      <i class="fas fa-check"></i>
      Paid 0 KP
    `;
    return;
  }

  const beforeKi = Number(
    actor.system.kiPool?.value || 0
  );

  const beforeCapacity = dbuGetCapacity(actor);

  try {
    const payment = await dbuPayKiAndCapacity(
      actor,
      amount,
      label
    );

    if (!payment.ok) {
      button.disabled = false;
      button.classList.remove("dbu-pay-pending");
      globalThis.DBU_PAY_LOCKS.delete(payLockKey);
      return;
    }

    button.classList.remove("dbu-pay-pending");
    button.classList.add("dbu-pay-paid");

    button.innerHTML = `
      <i class="fas fa-check"></i>
      Paid ${amount} KP
    `;

    const afterKi = Number(
      actor.system.kiPool?.value || 0
    );

    const afterCapacity = dbuGetCapacity(actor);

    console.log(
      "DBU | PAY depois:",
      {
        actor: actor.name,
        label,
        amount,
        kiBefore: beforeKi,
        kiAfter: afterKi,
        capacityBefore: beforeCapacity.spent,
        capacityAfter: afterCapacity.spent,
        capacityLeft: afterCapacity.left
      }
    );

    const whisperIds = game.users
      .filter(
        user =>
          user.isGM
          || actor.testUserPermission(
            user,
            "OWNER"
          )
      )
      .map(user => user.id);

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({
        actor
      }),

      whisper: whisperIds,

      content: `
        <div class="dbu-ki-deduct">
          <b>${dbuEsc(actor.name)}</b>
          <br>
          ${dbuEsc(label)}: <b>-${amount} KP</b>
          <br>
          Ki: <b>${beforeKi} → ${afterKi}</b>
          <br>
          Capacity Spent:
          <b>${beforeCapacity.spent} → ${afterCapacity.spent}</b>
          <br>
          Capacity restante:
          <b>${afterCapacity.left} / ${afterCapacity.max}</b>
        </div>
      `
    });
  } catch (error) {
    console.error(
      "DBU | Erro no pagamento:",
      error
    );

    button.disabled = false;
    button.classList.remove("dbu-pay-pending");
    globalThis.DBU_PAY_LOCKS.delete(payLockKey);

    ui.notifications.error(
      error.message || "Erro pagando ação."
    );
  }
};

document.addEventListener(
  "click",
  dbuNativePayHandler,
  true
);

globalThis.DBU_BOOTSTRAP.nativePayHandler =
  dbuNativePayHandler;

// ============================================================
// LISTENER DA DEFESA
// ============================================================

const dbuDefenseClickHandler = async event => {
  const button = event.target.closest?.(
    DBU_DEFENSE_SELECTOR
  );

  if (!button) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();

  const defenderId = button.dataset.defenderId;
  const defenseType = button.dataset.dbuDefenseV5;

  if (!defenderId || !defenseType) {
    return ui.notifications.error(
      "Dados do botão de defesa inválidos."
    );
  }

  const defender = game.actors.get(defenderId);

  if (!defender) {
    return ui.notifications.error(
      "Defensor não encontrado."
    );
  }

  if (
    !game.user.isGM
    && !defender.isOwner
  ) {
    return ui.notifications.warn(
      `Você não controla ${defender.name}.`
    );
  }

  const messageElement = button.closest(
    "[data-message-id]"
  );

  const messageId =
    messageElement?.dataset?.messageId;

  if (!messageId) {
    return ui.notifications.error(
      "Mensagem do ataque não encontrada."
    );
  }

  const message = game.messages.get(messageId);

  if (!message) {
    return ui.notifications.error(
      "ChatMessage não encontrada."
    );
  }

  // v6.6 — United Attack só pode entrar antes da primeira defesa começar.
  await dbuRequestUnitedAttackLock(
    message,
    defender,
    true
  );

  const lockKey =
    `${messageId}:${defenderId}`;

  if (
    globalThis.DBU_DEFENSE_LOCKS.has(lockKey)
  ) {
    return ui.notifications.warn(
      `${defender.name} já está resolvendo esta defesa.`
    );
  }

  globalThis.DBU_DEFENSE_LOCKS.add(lockKey);

  let currentState = dbuGetDefenseState(
    defender,
    messageId
  );

  if (currentState?.resolved) {
    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

    return ui.notifications.warn(
      `${defender.name} já resolveu esta defesa.`
    );
  }

  if (currentState?.pending) {
    const age =
      Date.now()
      - Number(currentState.lockedAt || 0);

    if (age < DBU_PENDING_TIMEOUT) {
      globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

      return ui.notifications.warn(
        `${defender.name} já está resolvendo esta defesa.`
      );
    }

    await dbuClearDefensePending(
      defender,
      messageId
    );
  }

  const lockToken =
    `${game.user.id}-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2)}`;

  try {
    await dbuSetDefenseState(
      defender,
      messageId,
      {
        resolved: false,
        pending: true,
        defenseType,
        lockedBy: game.user.id,
        lockToken,
        lockedAt: Date.now()
      }
    );
  } catch (error) {
    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

    console.error(
      "DBU | Lock:",
      error
    );

    return ui.notifications.error(
      "Não consegui bloquear a defesa."
    );
  }

  await dbuSleep(50);

  currentState = dbuGetDefenseState(
    defender,
    messageId
  );

  if (
    currentState?.lockToken !== lockToken
  ) {
    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

    return ui.notifications.warn(
      `${defender.name} já está sendo defendido por outro usuário.`
    );
  }

  const attack = message.getFlag(
    "world",
    "dbuAttackData"
  );

  if (!attack) {
    await dbuClearDefensePending(
      defender,
      messageId
    );

    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

    return ui.notifications.error(
      "Dados do ataque não encontrados."
    );
  }

  const row = button.closest(
    "[data-target-row]"
  );

  const buttons = row?.querySelectorAll(
    DBU_DEFENSE_SELECTOR
  ) || [];

  buttons.forEach(
    b => b.disabled = true
  );

  try {
    const result = await globalThis.DBU
      .resolveDefense(
        defender,
        attack,
        defenseType,
        { message, deferReveal: true }
      );

    if (result?.cancelled) {
      await dbuClearDefensePending(
        defender,
        messageId
      );

      await dbuRequestUnitedAttackLock(
        message,
        defender,
        false,
        { safeUnlock: true }
      );

      globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

      buttons.forEach(
        b => b.disabled = false
      );

      return;
    }

    // Feedback visual imediato no cliente que escolheu a defesa.
    // O resultado numérico continua oculto até todos os alvos escolherem.
    const selectedDefenseName = String(
      result?.hiddenOutcome?.name
      || dbuDefenseChoiceLabel(defenseType)
    );

    try {
      const localStates = foundry.utils.deepClone(
        message.getFlag("world", "dbuDefenseStates") || {}
      );
      localStates[defender.id] = {
        ...(localStates[defender.id] || {}),
        resolved: true,
        pending: false
      };
      const localProgress = dbuCombatProgress(attack, localStates);
      if (row?.isConnected) {
        row.outerHTML = dbuWaitingTargetHTML(
          defender,
          localProgress,
          selectedDefenseName
        );
      }
    } catch (error) {
      console.warn("DBU | Feedback local da defesa:", error);
    }

    await globalThis.DBU
      .updateTargetStatus(
        message,
        defender,
        result.status,
        result.text,
        {
          ...result,
          selectedDefenseType: defenseType,
          selectedDefenseName
        }
      );

    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

    console.log(
      `DBU | Defesa concluída: ${defender.name}`
    );
  } catch (error) {
    console.error(
      "DBU | Defesa:",
      error
    );

    try {
      await dbuClearDefensePending(
        defender,
        messageId
      );

      await dbuRequestUnitedAttackLock(
        message,
        defender,
        false,
        { safeUnlock: true }
      );
    } catch {}

    globalThis.DBU_DEFENSE_LOCKS.delete(lockKey);

    buttons.forEach(
      b => b.disabled = false
    );

    ui.notifications.error(
      error.message || "Erro resolvendo defesa."
    );
  }
};

document.addEventListener(
  "click",
  dbuDefenseClickHandler,
  true
);

globalThis.DBU_BOOTSTRAP.defenseClickHandler =
  dbuDefenseClickHandler;

// ============================================================
// SINCRONIZAR UNITED ATTACK QUANDO FLAGS NATIVAS MUDAREM
// ============================================================

const unitedAttackActorHookId = Hooks.on(
  "updateActor",
  async (actor, changes) => {
    if (!dbuIsPrimaryGM()) return;

    const united = foundry.utils.getProperty(
      changes,
      `flags.${DBU_SYSTEM_ID}.unitedAttacks`
    );

    if (!united) return;

    try {
      for (const rawKey of Object.keys(united)) {
        const storageId = String(rawKey).replace(/^-=/, "");

        const custom = game.messages.contents
          .slice()
          .reverse()
          .find(message => {
            const attack = message.getFlag("world", "dbuAttackData");
            if (!attack) return false;
            return dbuUnitedAttackStorageId(message, attack) === storageId;
          });

        if (custom) {
          await dbuGMRefreshUnitedAttackCard({
            messageId: custom.id
          });
        }
      }
    } catch (error) {
      console.error("DBU | Sync United Attack actor hook:", error);
    }
  }
);

globalThis.DBU_BOOTSTRAP.unitedAttackActorHookId =
  unitedAttackActorHookId;

// ============================================================
// NOVO ROUND
// ============================================================

async function dbuNewRound(combat) {
  if (!dbuIsPrimaryGM()) return;

  const processed = new Set();

  for (const combatant of combat.combatants) {
    const actor = combatant.actor;

    if (
      !actor
      || processed.has(actor.id)
    ) {
      continue;
    }

    processed.add(actor.id);

    try {
      const sheet = actor.sheet;

      if (
        typeof sheet?._onCombatNewRound === "function"
      ) {
        await sheet._onCombatNewRound({
          preventDefault() {},
          stopPropagation() {}
        });

        console.log(
          `DBU | Novo Round -> ${actor.name}`
        );
      } else {
        console.warn(
          `DBU | _onCombatNewRound não encontrada para ${actor.name}`
        );
      }
    } catch (error) {
      console.error(
        `DBU | Novo Round ${actor.name}:`,
        error
      );
    }
  }
}

// ============================================================
// HOOK DO COMBAT TRACKER
// ============================================================

const combatHookId = Hooks.on(
  "updateCombat",
  async (combat, changes) => {
    if (
      !Object.prototype
        .hasOwnProperty
        .call(changes, "round")
    ) {
      return;
    }

    const round = Number(
      combat.round || 0
    );

    if (round <= 0) return;

    const key = `${combat.id}:${round}`;

    if (
      globalThis.DBU_BOOTSTRAP.lastCombatRound === key
    ) {
      return;
    }

    globalThis.DBU_BOOTSTRAP.lastCombatRound = key;

    await dbuNewRound(combat);
  }
);

globalThis.DBU_BOOTSTRAP.combatHookId =
  combatHookId;

// ============================================================
// TESTE MANUAL
// ============================================================

globalThis.DBU.test = function () {
  console.log(
    "============================="
  );

  console.log(
    "DBU Inicializador",
    DBU_INIT_VERSION
  );

  console.log(
    "resolveDefense:",
    typeof globalThis.DBU.resolveDefense
  );

  console.log(
    "Native Pay:",
    !!globalThis.DBU_BOOTSTRAP.nativePayHandler
  );

  console.log(
    "Defense handler:",
    !!globalThis.DBU_BOOTSTRAP.defenseClickHandler
  );

  console.log(
    "Socket handler:",
    !!globalThis.DBU_BOOTSTRAP.socketHandler
  );

  console.log(
    "Round hook:",
    globalThis.DBU_BOOTSTRAP.combatHookId
  );

  console.log(
    "Defense GIF notes:",
    "system.notes"
  );

  console.log(
    "Duel Clash injection:",
    !!globalThis.DBU_BOOTSTRAP.duelInjectHookId
  );

  console.log(
    "United Attack handler:",
    !!globalThis.DBU_BOOTSTRAP.unitedAttackHandler
  );

  console.log(
    "United Duel handler:",
    !!globalThis.DBU_BOOTSTRAP.unitedDuelHandler
  );

  console.log(
    "Duel Accept handler:",
    !!globalThis.DBU_BOOTSTRAP.duelAcceptHandler
  );

  console.log(
    "Duel Escape handler:",
    !!globalThis.DBU_BOOTSTRAP.duelEscapeHandler
  );

  console.log(
    "============================="
  );

  ui.notifications.info(
    `DBU Inicializador v${DBU_INIT_VERSION} funcionando.`
  );
};

// ============================================================
// FINAL
// ============================================================

console.log(
  "=========================================="
);
console.log(
  `DBU Inicializador v${DBU_INIT_VERSION}`
);
console.log(
  "✓ Ki + Capacity"
);
console.log(
  "✓ Pay de ataque cobra Capacity"
);
console.log(
  "✓ Ataque bloqueado se Cost + Wager exceder Ki/Capacity"
);
console.log(
  "✓ Uma defesa por ataque"
);
console.log(
  "✓ Player não edita ChatMessage"
);
console.log(
  "✓ GM atualiza carta via socket"
);
console.log(
  "✓ GIFs de defesa via system.notes"
);
console.log(
  "✓ Duel Clash na carta de defesa"
);
console.log(
  "✓ United Attack no ataque normal"
);
console.log(
  "✓ United Attack cobra Ki + Capacity"
);
console.log(
  "✓ Multi-target pode Join United Duel"
);
console.log(
  "✓ Accept Duel usa o ataque original"
);
console.log(
  "✓ Duel Escape usa o atacante original"
);
console.log(
  "✓ Duel Wager cobra Capacity"
);
console.log(
  "✓ Novo Round"
);
console.log(
  "=========================================="
);

ui.notifications.info(
  `DBU Inicializador v${DBU_INIT_VERSION} ativo.`
);


return globalThis.DBU;
}
